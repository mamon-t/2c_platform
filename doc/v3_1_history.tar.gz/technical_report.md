# 2C Platform — Технический отчёт о состоянии системы

> **Рабочий документ.** Локальный, не версионируется в git (в `.gitignore`).
> Обновляется по результатам каждой фазы разработки.

- **Дата:** 2026-09-13
- **Репозиторий:** локальный git в `/home/mikhail/develop/2C`

---

## 1. Статус

Платформа в стадии активного каркаса. Реализованы два независимых доменных
слоя (`core-domain`, `core-application`), **SurrealDB Event Store** в
`core-infrastructure` и репозитории Фаз 2-6 (компании, пользователи, роли,
**метаданные**, **объекты**, **аудит действий**) с транзакционной записью
«Доска+Труба», интегрированные в `platform-server` (debug REST
`POST /debug/command`) и проверенные на живом сервере `192.168.0.202:8000`.

**Фаза 5 (права доступа, ТЗ v3.1 Прил. №7):** строгий RBAC — `PermissionManager`
(алгоритм по приоритетам политик, deny-by-default, deny overrides allow) и
`CommandExecutionPipeline` (аудит + проверка прав + исполнение) встроены в
`CommandRegistry`; все 31 команда переведены на `register_with_metadata(... requires ...)`;
системные роли `admin/staff/guest/archived` и политики `platform.full`,
`staff.objects`, `guest.objects`, `archived.objects` сидятся командой `role.seed`;
конвейер администрируют `role.seed`/`system.migrate_permissions` (требуют
`role.manage`). Системный исполнитель (actor=None) обходит проверку — это
позволяет выполнить первый сид до появления аутентифицированных пользователей.

Проверено: сборка, тесты (114), clippy, отсутствие нежелательных зависимостей в доменных слоях.
Все комментарии в исходниках переведены на русский (коммит `f7e86b9`, конвенция AGENTS §11 актуализирована).

**Фаза 9 (WASM-хостинг, ТЗ v3.1 §9, подфаза 8a):** порт `WasmHost` (async API
`load_module/call_function/unload_module/is_loaded`), манифест модулей v2
(`ModuleManifest`, 18 полей, `validate()`), хост `ExtismWasmHost` на Extism 1.30
с лимитами (топливо 10M, память 256 страниц, таймауты 10/30 с) и host-функциями
подфазы 8a (whoami, now_ms, module_settings, log_message + KV: put/put_if_absent/
get/list/delete) в namespace `ExtismHost`; KV-хранилище `ModuleKv` (SurrealDB
`module_kv`, атомарный `put_if_absent`). Пример `examples/hello_plugin` собран в
WASM и проверен интеграционными тестами (4). Остались host-fn 8b–8d, декларативная
регистрация, `ModuleStore` и live-проверка (подфазы 9b–9c).

**Фаза 9 (ТЗ v3.1 §9, подфаза 8b, host-fn 8b):** host-функции объектов «Доски»
и метаданных в namespace `ExtismHost`: `objects.create` (`create_object` — валидация
`Object::validate`, начальное состояние из схемы, событие `object.created`),
`objects.read` (`get_object`, `list_objects` с `total_count` через новый
`ObjectRepository::count`), `objects.update` (`update_object` с OCC по ожидаемой
версии, событие `object.updated`) и `metadata.read` (`get_entity_type`,
`list_entity_fields`). Ошибки конверта маппятся через `DomainError::code()`
(Приложение №6 ТЗ: `NOT_FOUND_ERROR`/`CONFLICT_ERROR`/`VALIDATION_ERROR`/`STORAGE_ERROR`);
`block_on_kv` обобщён в `block_on_db`. Пример `examples/hello_plugin` расширен
экспортом `objects_probe` (создание/чтение/список), фикстура пересобрана, добавлен
интеграционный тест. Остались host-fn 8c–8d, декларативная регистрация, `ModuleStore`,
live-проверка (подфазы 9b–9c).

**Фаза 9 (ТЗ v3.1 §9, подфаза 9d):** реальные рантайм-сервисы модулей. 
`users_by_role` — host-fn «пользователи по роли» через новый порт
`UserRepository::list_by_role(role_id, company_id)` (гейт по компании роли:
роль из чужой компании или отсутствует → пустой список; ответ обогащается
`full_name` из персона и `email` из контактов). `preload_company_modules` —
`ModuleManager::preload_all`: при старте сервера загрузка установленных
модулей из кэша `{cache_dir}/{code}-{wasm_sha256}.wasm` и идемпотентная
повторная декларативная регистрация (политики/схемы/команды) для всех
включивших модуль компаний; ошибки по отдельным модулям нефатальны
(`PreloadReport.errors`). Генерация wasm-фикстуры переведена на локальный
`.cargo/config` с обёрткой линкера (отбрасывает `-fuse-ld=*` из глобального
конфига). Тесты 138.

**Фаза 9 (ТЗ v3.1 §9, транзакционная оркестрация tx_exec):** модули могут
выполнять пачки операций атомарно: `tx_begin(business_key)` → `tx_add_op(handle,
op_type, params_json)` → `tx_commit(handle)` (capability `transactions`).
`TransactionOrchestrator` держит активные транзакции в памяти (RwLock, GC 60 с,
TTL 5 мин), идемпотентен по `business_key` (повторный `begin` той же пачки
возвращает прежний handle и число уже добавленных операций), поддерживает
`$ref`-связывание `{"$ref": "<op_id>.path.to.field"}` между результатами операций
(лимит глубины 10) и атомарно применяет пачку через новый `ObjectRepository::update_batch`
(один `with_transaction`: OCC по версиям, единый `assign_versions` + `write_events` —
при сбое любой операции откатывается всё, handle остаётся активным). Операции:
`object.post`/`object.cancel` (прямая смена канонического `state`, требуют `id`,
опциональный `expected_version`) и `test.noop` (эхо параметров). Коды ошибок
конверта — Приложение №6 ТЗ через `DomainError::code()`.
`ObjectRepository` переведён на `BoxFuture` (все 11 методов) — trait-object для
`Arc<dyn ObjectRepository>`. Тесты 153.

**Фаза 10 (ТЗ v3.1 §10, подфаза 10a, транспортный слой):** конверт `RpcMessage`
(`Command`/`Query`/`EventBatch`/`Response`/`Error`/`ServerPush`, tag `type`,
snake_case) и REST-эндпоинт `POST /rpc` в новом крейте `core-api`
(`rpc_message`/`error_mapping`/`idempotency`/`routes`). Резолв команд:
`core`→action напрямую, иначе `plugin.{module}.{action}`; legacy-форма
`{name, params}` автоконвертируется (обратная совместимость с `/debug/command`).
Ошибки типизированы: команды и `CommandRegistry`/`CommandExecutionPipeline`
переведены с `Result<_, String>` на `Result<_, DomainError>`, что даёт коды
`RpcMessage::Error` (`NOT_FOUND_ERROR`/`CONFLICT_ERROR`/`VALIDATION_ERROR`/
`PERMISSION_ERROR`/`STORAGE_ERROR`), HTTP 404/409/422/403/500 и детали
`expected_version`/`actual_version` при `VersionConflict`. Идемпотентность
`(actor_user_id, request_id)` с TTL 5 минут и фоновым GC (60 c) — `IdempotencyStore`
(кэшируются только `Command`). `EventBatch` (module=`core`) append'ится в Трубу
напрямую. `EventStore` переведён на `BoxFuture` (object-safe, `Arc<dyn EventStore>`
в `ApiState`). Интеграционные тесты `tests/phase10a_rpc.rs` (10) через
`Router::oneshot`, юнит-тесты idempotency (3). Всего тестов 166.

**Фаза 10 (ТЗ v3.1 §10, подфаза 10b, аутентификация JWT):** `user.login`/`user.logout`
в `commands.rs`, сервис `AuthService` (core-application, `auth.rs`) поверх портов
`UserRepository`/`AuditRepository` и нового порта `TokenManager` (`AuthToken`,
`issue`/`parse`). Пароли — Argon2id через `core_domain::password`
(`hash_password`/`verify_password`, salt `OsRng`; в `user.create`/`user.update`
параметр `password_hash` заменён на `password` с хэшированием на сервере).
Неудачный логин аудитируется (`user.login_failed`), при ≥5 неудачах аккаунт
блокируется на 15 минут (`locked_until`); успешный — сбрасывает счётчик и пишет
`user.login`. `JwtTokenManager` (core-api, `token.rs`, jsonwebtoken 9): claims
sub/login/full_name/position/company_id/iat/exp, HS256-подпись, `access_ttl` из
`JWT_SECRET`-env (main.rs). `POST /rpc` разрешает актора из заголовка
`Authorization: Bearer <jwt>` (без токена — `ActorSnapshot::anonymous()`),
`IdempotencyKey` получил actor_user_id. **Фикс RBAC:** явный анонимный актор
(без `user_id`, не `system`) больше не обходит `required_permission` — только
системный исполнитель и внутрипроцессные вызовы (`ctx.actor == None`). Юнит-тесты
password (3), idempotency (3), token (3); интеграционные `tests/phase10b_auth_rpc.rs`
(8: login/ошибки/блокировка/аноним-403/system/admin/staff/logout). Всего тестов 180.

**Фаза 10 (ТЗ v3.1 §10, подфаза 10c, WebSocket/ServerPush):** `PushHub`
(`core-api/push_hub.rs`) — broadcast-канал `RpcMessage` (ёмкость 256), `push()`
публикует `RpcMessage::ServerPush { id, module, event_type, payload }`.
Эндпоинт `GET /ws` (`core-api/ws.rs`, `ws_handler`/`ws_session`): актор из
`Query?token=<JWT>` (без токена — `ActorSnapshot::anonymous()`), входящие
Command/Query/EventBatch парсятся в `RpcMessage` и проходят через общий
`process()` (тот же, что и в `POST /rpc`), ответы и ServerPush уходят клиенту
текстовыми JSON-фреймами через исходящий канал; `select!` следит и за сокетом,
и за лентой хаба (Lagged — пропуск). В `routes.rs` выделены `process()`/
`respond()`/`http_status_for_code()` (общие для REST и WS); `POST /debug/push`
публикует ServerPush в хаб. Юнит-тесты push_hub (2); интеграционные
`tests/phase10c_ws.rs` (3: echo-команда по WS, ServerPush второму клиенту,
EventBatch → append в Трубу). Всего тестов 185.

**Смена адреса сервера:** с 2026-09-06 04:03 MSK адрес SurrealDB по умолчанию
изменён с `192.168.31.31:8000` на `192.168.0.202:8000` (файлы `.env`).

**Фаза 13 (ТЗ v3.1 §15, скрипты Rhai):** скриптовый движок `RhaiScriptEngine`
(песочница: `Engine::new_raw()` без `file`/`net`, fuel 10M, лимиты коллекций
1 MiB и вложенности 64, выполнение на OS-потоке `rhai-script` с жёстким
таймаутом, кэш AST до 128), Core API (`CoreApiShared` + `await_core_api` —
паттерн «spawn на владеющем рантайме + std-канал»): `log_info`/`log_error`
(аудит `script.log`), `emit_event`, `emit_transaction`, `db_query`.
`ScriptRepository` (SurrealDB) + модель `Script` (core-domain), `ScriptContext`
(`script_context.rs`, поля `args`/`user`/`company_id`/`entity_type`/`action`/
`object`/`changes`/`settings`/`test_run`), манифестные скрипты в `ModuleManifest`
(валидация, дедупликация `code`). Host-fn `run_script` переведена с заглушки 9c
на реальный движок; рефакторинг `CommandHandler` → `Fn(Value, CommandExecutionCtx)`
(актор из JWT проброшен в команды, ~69 точек регистрации); логика исполнения
вынесена в `script_runner::execute_script` (валидации: `code` обязателен, запись
активна, bind к `entity_type` ↔ `object`, маппинг в `ScriptContext` с
`action="execute"`); политика `platform.scripts` (seed, namespaced actions
`script.manage`/`script.execute`/`script.read`, priority 90, без привязки к ролям);
команды `script.create`/`script.update`/`script.delete` (capability `scripts`,
require `script.manage`), `script.list`/`script.get`/`script.validate` (require
`script.read`; validate — только AST через `engine.validate`), `script.execute`
(require `script.execute`) (platform-server). Допущение: точный матчинг actions в
RBAC (префикс `script.` обязателен; `staff.objects`/`guest.objects` членов не
дают — staff/guest/archived изолированы от `script.*`, единственный исполнитель —
admin через `platform.full`). Отладка WASM-пути: `run_script` в
integration-тесте висел ровно 8с — блокирующий `rx.recv_timeout` на std-канале
внутри async-задачи замораживал воркер tokio, где живёт task-драйвер SurrealDB
mem:// (поэтому `db.begin()` ждал освобождения); заменён на `tokio::sync::mpsc` +
`tokio::time::timeout` (begin: 1.6 мс). Тесты 210 (^ `phase13_scripts` +5).

**Доработка перед Фазой 11б (SDUI-навигация):** системная политика
`platform.modules` (action `module.read`, `record_access` ByCompany, priority 40)
в сиде + привязка к `staff`/`guest` (admin — через `platform.full`, archived —
никак). `seed_system_roles_and_policies` возвращает `SeedSummary{roles_created,
policies_added}` и **дополняет** существующие системные роли недостающими
политиками через новый `RoleRepository::update` (+ событие `role.updated`).
`ManifestNavItem` получил `entity_type: Option<String>` (serde default — старые
манифесты парсятся). Команда `module.navigation` (`requires("module.read")`,
без параметров, компания из актора ИЛИ `params.company_id`) через новый
`ModuleManager::get_navigation`: модули = `list_enabled_for_company`, фильтр по
`PermissionManager::check` на `required_permission` каждой команды модуля
(нет ни одной доступной — модуль исключён), срез ответа — только `{code,
display_name, version, navigation[{code,label,entity_type}]}` (без манифеста,
`wasm_sha256`, capabilities). `accounting_plugin` получил навигацию
(accounts/periods/entries), фикстура `accounting.wasm` пересобрана.
`system.migrate_permissions` сидит **все** компании и возвращает/пишет в аудит
`{companies_total, seeded, policies_added}` (идемпотентно). `PermissionManager`
строится до регистрации команд модулей (передаётся и в phase9, и в
`attach_pipeline`). Интеграционные тесты `phase11_navigation` (8). Всего 251.

**system.bootstrap (однократная инициализация платформы):**
`core-application/src/bootstrap.rs` — `bootstrap_platform` (8 шагов: 1) проверка
идемпотентности: код-коллизия → «Компания {code} уже существует», непустая БД →
«Платформа уже инициализирована. Для добавления компаний используйте
company.create»; 2) компания (`company.created`); 3) суперадмин (`user.create`,
Argon2id, `must_change_password`); 4) `seed_system_roles_and_policies`;
5) привязка `user.role_ids = [admin]` (`user.updated`); 6) primary-профиль
(`user_profile.created`); 7) аудит `system.bootstrap` от системного актора с
деталями {company_code, admin_login, roles_created, policies_seeded}). Команда
`system.bootstrap` зарегистрирована с `CommandMetadata::requires("system.bootstrap")`
— политики с таким действием нет, поэтому доступна только системному
исполнителю (POST `/debug/command`); аноним и аутентифицированный → `PERMISSION_ERROR`.
При старте, если компаний нет, в лог выводится warn с готовым примером команды
(запуск не блокируется). Интеграционные тесты `phase_bootstrap` (6: полный цикл,
повторный вызов, коллизия кода, отказ анониму, login root, неверный пароль).

**Расширение 1 (ТЗ v3.1_1, фазы 15pre-1/15pre-2):** `system.bootstrap` теперь
засевает **системные метаданные** (`metadata_seed.rs`, 7 глобальных типов
`company`/`user`/`role`/`entity_type`/`entity_field`/`entity_state`/
`entity_transition` с `is_system=true` и `company_id=""`; у `user` — состояния
active/blocked и переход block) через generic `M: MetadataRepository`;
`BootstrapResult.metadata_entity_types_seeded`. Ядровые сущности рендерятся в
SDUI-клиенте: `object.*` делегируются в репозитории компаний/пользователей/ролей
(маппинг в универсальную Object-форму, OCC в generic-пути), synthetic-модуль
`platform` появляется в `module.navigation` (гейт — права `read`), системные
схемы разрешаются из глобального `company_id=""` для любой компании (фолбэк
только для `is_system`-типов). Сервер: юнит-тесты 5 в `commands.rs` +
расширенные `phase_bootstrap` (6) + `phase11_navigation` (8) +
`surreal_metadata_repository` (7). Клиент: `home_screen_test` (5) +
`core_entity_catalog_test` (4), всего клиентских тестов 121.

**Расширение 1 (ТЗ v3.1_1, фаза 15pre-3 — редактор метаданных + экспорт/импорт):**
`MetadataRepository` расширен `export_entity_type`/`import_entity_type`
(`surreal_metadata_repository`: экспорт = схема → JSON; импорт =
`from_value::<EntitySchema>` + `create_entity_type` + событие
`metadata.entity_type.imported`); orphan-синхронизация `delete_orphans`
(после каждой группы апсёрта дочерних ресурсов по кодам из схемы, иначе
переходы/поля, удалённые в схеме, «висели» в БД); команды `metadata.export`
(право `metadata.read`) и `metadata.import` (право `metadata.manage`),
в wire-контракте обязательны `entity_type.{code,name,kind,metadata_version}` +
`fields[].{code,label,data_type}` + `transitions[].{code,label,from_state,to_state}`,
ensure-семантика: версия ≤ сохранённой → no-op (клиент бампит
`metadata_version` при каждом сохранении); пункт «Метаданные» в
`module.navigation` за гейтом `metadata.manage`. Клиент: модели
`toJson/copyWith` (+`EntityType.id`/`metadataVersion`), `MetadataService`
(`createEntityType`/`exportMetadata`/`importMetadata` со сбросом кэша),
SDUI-скрин `metadata_editor_screen` (выбор типа из `schemasProvider`,
диалоги «Новый тип»/Поля/Состояния/Переходы, каскадное удаление переходов
при удалении состояния, guard «последнего состояния», сохранение =
бамп версии + `metadata.import`, экспорт/импорт JSON), роут
`/metadata/editor/:entityType?` и пункт в drawer (code `metadata`).
Сервер: тестов 25 (platform-server 7, repo 12, phase11 8, phase_bootstrap 6,
phase14 12 — все зелёные), clippy 0. Клиент: новый
`metadata_editor_screen_test.dart` (10), всего клиентских тестов 131.

**Фаза 15 (ТЗ v3.1 §15/§19, скрипты Rhai — редактор, подфаза 15.2):**
клиентский каталог скриптов. Модель `ScriptItem` (core-domain `Script`,
wire `script_type` snake_case, опциональные `company_id`/`module_code`/
`entity_type`); сервис `ScriptService` (`script.list/get/create/update/
delete/validate/testRun`, null-aware `company_id`), провайдер `scriptsProvider`
(подписка на `_authRevision`). Экран `ScriptListScreen` (`/scripts`):
DataTable Код/Название/Тип/Статус (метки типов формула/валидатор/перед
действием/после действия/отчёт/обработчик события), FAB «Создать»,
RefreshIndicator, пусто → «Нет скриптов». Экран `ScriptEditorScreen`
(`/scripts/new`, `/scripts/:code/edit`): форма код/название/тип/тип сущности/
активен/исходник (monospace), кнопки «Проверить» (`script.validate` —
панель «Синтаксис в порядке»/«Ошибки проверки» с координатами Строка L:C —
сообщение) и «Прогнать» (`script.test` → «Результат: … · N мс», у созданных
скриптов требует сохранения). Пункт «Скрипты» (`code: scripts`) в
synthetic-навигации platform за правом `script.manage` (зеркало «Метаданных»);
`home_screen._routeFor` → `/scripts`. Роуты: `/scripts`, `/scripts/new`,
`/scripts/:code/edit`. Тесты: клиент 4 файла (model 4, service 11, list 5,
editor 8) + home-кейс «Скрипты» — всего клиентских 159, analyzer 0;
сервер: phase11_navigation 8/8 (admin видит scripts, staff — нет), clippy 0.

**Фаза 15 (ТЗ v3.1 §15/§19, скрипты Rhai — редактор, подфаза 15.1):**
`script.test` (право `script.manage`) — отладочный прогон скрипта через
`script_runner::test_script`: `test_run=true`, **без гейтов `is_active`
и `object`** (можно отлаживать отключённый или привязанный к типу скрипт),
`action="test"`, замер через `Instant` → успех `{result, execution_time_ms}`,
runtime-ошибка → `DomainError::ScriptFailure` с координатами.
`script.validate` (право `script.read`) — **структурированная** проверка:
контракт ответа `{valid: bool, errors: [{line, column, message}]}` (был
флагом без деталей), параметры `source` (исходник) или `code` (уже
сохранённый скрипт, опционально `company_id`), bind-проверка существования
`entity_type` через `MetadataRepository` (нет → ошибка в `errors[]` без
координат). Координаты ошибок — новые типы: `DomainError::ScriptFailure{
message, line, column}` (код `VALIDATION_ERROR`, в маппинге core-api →
HTTP 422 + `error_details{line, column}`) и `ScriptError{message, line,
column}` (сериализация `skip_none`) в core-domain; позиции из rhai
`ParseError::position()`/`EvalAltResult::position()` (в rhai 1.26 колонка —
`position()`, строка — `line()`); `RhaiScriptEngine::validate` теперь
возвращает `Result<(), ScriptError>`; host-fn Extism: `ValidationError |
ScriptFailure` → `INVALID_ACTION`. Интеграционные тесты `phase13_scripts`
дополнены 8 (test happy/timing, args, runtime-ошибка с координатами,
отключённый, привязанный без object, validate syntax-ошибка/валидный/
привязка к несуществующему типу) — всего 13. Тесты: phase13_scripts 13 + 7
(platform-server), clippy 0. **Бэклог:** авто-хук привязанных скриптов в
object-конвейер реализован в 15.4 (`2bcf6d0`) — см. §2 таблицу фаз.

**Фаза 15 (ТЗ v3.1 §15/§19, скрипты Rhai — редактор, подфаза 15.4):**
авто-хук привязанных скриптов в object-конвейер. Новый модуль
`core-application/script_hooks.rs`: `object_pre_hooks` (formula → validator →
before_action) и `object_after_hooks` (after_action). Привязка через
`load_active_scripts` (`ScriptRepository::list(Some(company_uuid))` —
компания+глобальные; при `company_id==""` — только глобальные), фильтр
`is_active` + `entity_type == Some`. Formula-скрипт (Rhai-map `#{key: expr}`)
выполняется первым: результат-объект **сливается в `object.computed`**
до валидации схемы (скаляры игнорируются); validator получает уже
вычисленный `.computed` и при `false` → `ValidationError` «валидатор …
отклонил объект …»; before_action/after_action выполняются до/после записи,
любая ошибка прерывает команду (при after_action объект уже в БД —
зафиксировано). Контекст: `user` из `ctx.actor` (фолбэк `ActorSnapshot::system()`),
`company_id` из `parse_company_id`, `entity_type: Some`, `action`,
`object`=сериализованный Object JSON, `changes`=params.data, `settings: json!({})`,
`test_run: false`. Встроено в `object.create`/`object.update` (`register_object_commands`
получил `scripts`/`engine`, строки 1116-1390). Тесты: +2 в `commands.rs`
(formula+validator: qty:3×price:150 → `computed.total==450`, отрицательный
итог → отказ; before+after: «запрещено до записи»/«уже записано», после
after объект сохранён), object_-тесты 7/7; полный `cargo test --workspace`
PASS; clippy 0. Регрессионный фикс `1316fed`: `engine_blocks_fs_access` под
`ScriptFailure` (см. §6).

### Журнал снимков

| Коммит | Дата | Что зафиксировано | Разделы отчёта |
|---|---|---|---|
| `2bcf6d0` | 2026-09-17 | **feat(phase15-4): авто-хук привязанных скриптов в object-конвейер** — `core-application/script_hooks.rs`: `object_pre_hooks` (formula → validator → before_action) и `object_after_hooks` (after_action); привязка по `is_active` + `entity_type`, компания через `list(Some(company_uuid))` (компания+глобальные) при `company_id==""` → глобальные; formula-merging Rhai-map в `object.computed` до валидации схемы; validator `false` → `domain.ValidationError` «валидатор … отклонил объект»; before/after прерывают команду (после записи объект уже в БД — зафиксировано); контекст: `user` из `ctx.actor` (фолбэк system), `action`="object.create"/"object.update", `object`=сериализованный Object, `changes`=params.data, `test_run`=false; встроено в `object.create`/`object.update`; тестовый `Env` + scripts/engine (CoreApiShared + `RhaiScriptEngine`); +2 теста (formula+validator: computed.total==450, отрицательный итог → отказ; before+after: «запрещено до записи»/«уже записано», после after объект сохранён), object_-тесты 7/7; полный `cargo test --workspace` PASS; clippy 0; untracked `doc/TZ_v4.0_Eventra.md` (не мой, требует внимания) | §1–§2, §2 (таблица), §7 |
| `1316fed` | 2026-09-17 | **fix(phase13): классификация ошибок в тесте `engine_blocks_fs_access` под `ScriptFailure`** — регрессия этапа 15.1: тест ожидал `ValidationError`, `classify_runtime_error` с 15.1 возвращает `ScriptFailure` (лимиты/переполненение → Storage, остальное → ScriptFailure с line/column); FS реально блокируется (read_file не зарегистрирована → «Function not found» → ScriptFailure); core-infrastructure зелёный | §6 |
| `772bd07` | 2026-09-17 | **feat(phase15-2): каталог скриптов (ScriptListScreen/ScriptEditorScreen)** — клиент: модель `ScriptItem`; `ScriptService` list/get/create/update/delete/validate/testRun (контракт `{valid,errors:[{line,column,message}]}`), `scriptsProvider` (подписка на `_authRevision`); `ScriptListScreen` `/scripts` (DataTable Код/Название/Тип/Статус + метки типов, FAB, RefreshIndicator); `ScriptEditorScreen` `/scripts/new`+`/scripts/:code/edit` (форма + «Проверить»=script.validate с панелью координат + «Прогнать»=script.test с временем); пункт «Скрипты» в synthetic-навигации платформы за `script.manage`; сервер: `ModuleManager::get_navigation` выдаёт `scripts`, phase11_navigation 8/8 (admin видит, staff — нет); клиентские тесты 4 файла + home-кейс «Скрипты» = 159, analyzer 0; clippy 0 | §1–§2 |
| `38180e4` | 2026-09-17 | **feat(phase15-1): script.test + structured script.validate** — `script.test` (`script.manage`): `test_script` (test_run, без гейтов `is_active`/`object`, action="test", `Instant` → `{result, execution_time_ms}`); `script.validate` (`script.read`): контракт `{valid, errors:[{line,column,message}]}`, параметры `source`/`code`+`company_id`, bind-проверка `entity_type` через `MetadataRepository`; новые `DomainError::ScriptFailure{message,line,column}` (VALIDATION_ERROR, 422 + `error_details{line,column}`) и `ScriptError` (core-domain, serde skip_none); позиции rhai `ParseError::position()`/`EvalAltResult::position()` (col=position, line=line в rhai 1.26); `ScriptEngine::validate` → `Result<(),ScriptError>`; Extism `ValidationError\|ScriptFailure`→`INVALID_ACTION`; тесты phase13_scripts +8 (итого 13), clippy 0, platform-server 7; бэклог: авто-хук скриптов в object-конвейер — отложен | §1–§2 |
| `5caf46f` | 2026-09-16 | **feat(phase15pre3): metadata editor with export-import** — `MetadataRepository::export_entity_type/import_entity_type` (surreal: экспорт схема→JSON; импорт `from_value`+`create_entity_type`, событие `metadata.entity_type.imported`), orphan-синхронизация `delete_orphans`; команды `metadata.export` (metadata.read) / `metadata.import` (metadata.manage); пункт «Метаданные» в `module.navigation` за `metadata.manage`; клиент: модели `toJson/copyWith`, `MetadataService` export/import/create + сброс кэша, SDUI-редактор `metadata_editor_screen` (секции Поля/Состояния/Переходы, диалоги, guard последнего состояния, бамп `metadata_version` при сохранении, экспорт/импорт JSON, «Новый тип»), роут `/metadata/editor/:entityType?`; тесты: сервер clippy 0 (platform-server 7, repo 12, phase11 8, bootstrap 6, phase14 12), клиент analyze 0 + `metadata_editor_screen_test` (10), всего клиентских тестов 131 | §1–§2, §2 (таблица), §7 |
| `2a837d6` | 2026-09-16 | **feat(phase15pre2): SDUI ядровых сущностей** — делегация `object.create/get/list/update` для `company/user/role` в `commands.rs` (helpers `fetch_core_entity`/`list_core_objects`/`create_core_object`/`update_core_object`/`*_to_json`/`parse_user_status`; OCC `expected_version` теперь обязателен только в generic-пути); synthetic-модуль `platform` (Компании/Пользователи/Роли) в `ModuleManager::get_navigation` (гейт — права `read`); global-fallback системных типов в `get_entity_type_by_code` (из `company_id=""` только `is_system`); юнит-тесты сервера 5 в `commands.rs` + тест в `surreal_metadata_repository.rs` (7/7); клиент: `home_screen_test.dart` (5) + `core_entity_catalog_test.dart` (4), `testSecureStorage()`, роуты `/home`+`/settings` в тестовом роутере; флатер 121/121, сервер 8/8+6/6+5/5 | §1–§2, §2 (таблица), §5 |
| `9646899` | 2026-09-16 | **feat(phase15pre1): системные метаданные** — `core-application/metadata_seed.rs` (`seed_system_metadata`, `system_metadata_schemas`, `system_metadata_type_count`, 7 системных типов с `is_system=true` и `company_id=""`, у `user` состояния active/blocked + переход block); `bootstrap_platform` → generic `M: MetadataRepository` + вызов сидинга, `BootstrapResult.metadata_entity_types_seeded`; `metadata.*` аудит-детали; `register_bootstrap_command`/main передают metadata; интеграционные тесты `phase_bootstrap` расширены (7 типов, `is_system`, схема `user`) — 6/6 | §1–§2, §2 (таблица), §6 |
| `38d493a` | 2026-09-15 | docs(agents): Фаза 11 завершена — AGENTS.md параграф 11b переписан (тесты 112, полировка 11b.6 тем, живой integration-прогон) | §1–§2 |
| `05535d2` | 2026-09-15 | **test(phase11b): live integration** — `integration_test/sdui_live_test.dart` против живого сервера (login → module.navigation → каталог → edit → create → OCC-конфликт CONFLICT_ERROR → смена темы); фиксы по прогону: роутер при `AuthRestoring` редиректит на `/login` (защищённые экраны не монтировались анонимно), сетевые sdui-провайдеры подписаны на `_authRevision` (перезапуск после входа/выхода — устранён кэш анонимного PERMISSION_ERROR); регрессия: analyze 0, юнит 112, build linux OK | §1–§2 (клиент) |
| `6c67e5d` | 2026-09-15 | **feat(phase11b-6): темы и полировка клиента** — TOML-подмножество `core/toml_subset.dart`, каталоги `AppPaths` (2CPLATFORM_CONFIG_DIR/XDG/HOME), `ThemeStore` (~/.config/2cplatform: themes/*.toml + config.toml `[app] theme`, сидинг example.toml, встроенные светлая/тёмная + файловые), `buildAppTheme` (ColorScheme.fromSeed + InputDecorationTheme), `appThemeProvider` (AsyncNotifier), переключатель в «Настройках»; юнит-тесты +19 (итого 112) | §1–§2 (клиент) |
| `7545835` | 2026-09-15 | **fix(phase11b): передавать company_id в metadata.schema.get** — live-находка: сервер ищет схему по (company_id, code) без подстановки актора; `MetadataService.fetchSchema(entityType, {companyId})` + `schemaProvider` из claims; тест +1 (итого 93) | §1–§2 (клиент), §7 |
| `e2cf2de` | 2026-09-15 | docs(agents): статус Фазы 11b (SDUI-клиент) в AGENTS.md | §1–§2 |
| `302e224` | 2026-09-15 | **feat(phase11b): SDUI-рендеринг в Flutter-клиенте** — модели entity_schema/object/navigation_item, RpcMessage.payload `Object?` + queryAny/commandAny, MetadataService+ObjectService, sdui-провайдеры (companyId из JWT-claims), WidgetRegistry + 12 тип-виджетов (money-копейки, date/datetime, enum, reference, array/table, json, read-only), CatalogScreen (DataTable из полей схемы) + ObjectFormScreen (create/view/edit, OCC expected_version, CONFLICT→диалог), роуты `/catalog/:entityType`, `/object/:entityType/{new|:id|:id/edit}`, home_screen drawer из module.navigation; тесты клиента 112; analyze 0, build linux OK | §1–§2 (клиент) |
| `6d55b49` | 2026-09-14 | chore(docs): AGENTS.md — ключевые файлы (+`bootstrap.rs`, сид «4 роли/6 политик»), статус фаз (доработка перед 11б, `system.bootstrap`, тестов 251, «Не начинать Фазы 11–12, 15+») | §1 |
| `7ac3aca` | 2026-09-14 | **system.bootstrap:** команда однократной инициализации платформы — `core-application/src/bootstrap.rs` `bootstrap_platform` (проверка идемпотентности код-коллизия→«Компания {code} уже существует», непустая БД→«Платформа уже инициализирована…»; компания → `user.create` Argon2id → `seed_system_roles_and_policies` → привязка `user.role_ids`=`[admin]` + `user.profile.add` primary → аудит `system.bootstrap`), `CommandMetadata::requires("system.bootstrap")` (только системный актор через `/debug/command`; аноним/аутентифицированный → PERMISSION_ERROR), warn при старте если компаний нет; интеграционные тесты `phase_bootstrap` (6: полный цикл, повторный вызов, коллизия кода, аноним-отказ, login root, неверный пароль) | §1–§2, §5, §6 |
| `bfa782e` | 2026-09-14 | **Доработка перед 11б (SDUI-навигация):** системная политика `platform.modules` (`module.read`, ByCompany, priority 40) в сиде + привязка `staff`/`guest`; `seed_system_roles_and_policies` → `SeedSummary{roles_created, policies_added}` и дополнение существующих ролей недостающими политиками; `RoleRepository::update` (+ событие `role.updated`); `ManifestNavItem.entity_type`; `ModuleManager::get_navigation` (срез {code, display_name, version, navigation[]}, фильтр по доступным командам актора через PermissionManager); команда `module.navigation` (`module.read`); `system.migrate_permissions` → сид ВСЕХ компаний, аудит/ответ `{companies_total, seeded, policies_added}`; `PermissionManager` строится до регистрации команд модулей; `accounting_plugin`: navigation (accounts/periods/entries), пересборка `accounting.wasm` (273368 байт); интеграционные тесты `phase11_navigation` (8) | §1–§2, §5, §5б, §6 |
| `a135a09` | 2026-09-14 | chore(clippy): пакет Update Phase 14 — закрыты все предупреждения: `#[allow(clippy::too_many_arguments)]` + обоснование (DI-конструкторы) на `ModuleManager::new` и `ExtismWasmHost::new`, убран `let _ = ` (let-unit) в тесте оркестратора; `cargo clippy --workspace --all-targets` — 0 предупреждений | §6, §7 |
| `b62a835` | 2026-09-14 | **Фаза 14, Правка 4 (object.create в оркестраторе):** тест-инфраструктура — `MemMetadataRepo` сделан скоуп-аварным по компании (ключ `(company_id, code)` у `schemas`, `get_entity_type_by_code`/`get_schema` с ошибками `NotFound`, lifetime-фикс через владеющую ошибку в `async move`); хелпер `seed_account_schema(metadata, company_id)`; +2 теста: `object_create_invalid_data_rejected_and_batch_rolled_back` (отсутствует обязательное поле → `ValidationError`, пачка откачена — `repo.all()` пуст) и `object_create_foreign_entity_type_rejected` (тип сущности существует только в чужой компании → `NotFound`, пачка откачена) | §1–§2, §5, §5е, §5и |
| `d0b3919` | 2026-09-14 | **Фаза 14, приёмочные тесты правок 2–3:** hello-плагин — манифест-команда `echo` (code≠function: `{code:"echo", function:"greet", required_permission:"hello.greet"}`, в КОНЕЦ массива commands — `commands[0]` не тронут) и экспорт `type_by_code_probe(code)` (host `get_entity_type_by_code`, конверт `{ok, data{id,code,name,kind}}`); пересборка фикстуры `hello.wasm` (lld-wrapper, 165765 байт); `hello_wasm.rs` +test `host_ges_entity_type_resolves_by_code_with_capability_gate` (резолв по коду + `NOT_FOUND` + `CAPABILITY_DENIED` без cap `metadata.read`); `phase9b_modules.rs` +test `manifest_command_with_function_maps_to_wasm_export` (`plugin.hello.echo` исполняет экспорт greet — «Привет») | §1–§2, §5, §5е, §5и, §6 |
| `396f311` | 2026-09-14 | AGENTS.md, §Конвенции проекта: добавлено правило «Денежные суммы» — только целые копейки (`Money(i128)` в core-domain, плагины на `i64`-копейках), `f64`/`f32` для денег запрещены, дробные суммы отклоняются валидацией `FieldType::Money` | §7 |
| `248c5c0` | 2026-09-14 | **Фаза 14, Правка 1 (Money):** новый `Money(i128)` в `core-domain` (`money.rs`) — копейки, `ZERO`/`PRECISION=2`/`SCALE=100`, `from_kopecks`/`from_rubles`, арифметика `Add/Sub/Neg/Mul/Sum`, `Display` («12345»→«123.45»); serde: сериализация строкой целых копеек, десериализация целого/строки, дробные → ошибка; `FieldType::Money` в `Object::validate` (`object.rs`) — только целые копейки (число i64/u64 или строка-`i128`), дробь/строка с разделителем → `ValidationError`; экспорт `money::Money` в `lib.rs`; юнит-тесты Money (+8) и валидации (+1); тестов всего 232 | §1–§2, §5, §5е |
| `2a562e3` | 2026-09-14 | **Фаза 14, accounting на копейки:** `validate_entry_lines` — суммы `i64-копейки` (`as_i64`), отрицательные/нецелые → ошибка, строгое `debit_total != credit_total` (без EPS); удалена `BALANCE_EPS`; `balance.trial`/`balance.sheet` — `BTreeMap<String, i64>`, skip `amount == 0`, итоги i64; `entry_list_impl` `map_or`→`is_some_and` (clippy); пересборка фикстуры `accounting.wasm` (lld-wrapper, 273040 байт); тест `phase14_accounting`: удалён `approx`, 14 ассертов на `as_i64()` (точная копеечная сверка) | §1–§2, §5, §5е, §5и, §7 |
| `ad4954e` | 2026-09-13 | AGENTS.md, §Конвенции проекта: добавлено обязательное правило — факты live-тестирования (неожиданности/ограничения против живой SurrealDB: отказ прав по `company_id`, кривые сценарии, роутинг) фиксировать в §7 отчёта сразу по факту как источник истины наравне со снимками коммитов | §7 |
| `b2b9202` | 2026-09-13 | AGENTS.md: статус фаз — Фаза 14 (модуль управленческого учёта, ТЗ §14) завершена; описание платформенной поддержки (function-команды, `options`, `get_entity_type_by_code`, `object.create` в транзакциях) и модуля `plugin.accounting` (13 команд, 3 схемы, permissions, live-цикл /rpc) | §1–§2 |
| `c42f95c` | 2026-09-13 | **Фаза 14 (модуль):** `plugin.accounting` — управленческий учёт: манифест (13 команд с `function`, 3 схемы account/accounting_period/ledger_entry, 3 permissions accounting.manage/read/post, capabilities objects.*/events.emit/transactions/metadata.read), пример `examples/accounting_plugin` (вне workspace, lld-wrapper, сборка была32), фикстура `accounting.wasm`, интеграционные тесты `phase14_accounting` (12 сценариев: CRUD счетов/периодов, проводки, сторно, фильтры, doc.post через транзакцию, ОСВ, баланс), всего тестов 223; live-цикл /rpc + Bearer JWT (account.create → period.open → entry.post → balance.trial) | §1–§2, §5, §5е, §5и, §6, §7 |
| `6459d5c` | 2026-09-13 | **Фаза 14 (платформа):** манифестные команды с `function` (WASM-экспорт подчёркиванием при registry-имени `plugin.{code}.{code}`), `ManifestField.options` → enum-валидация в `build_schema`, host-fn `get_entity_type_by_code` (cap `metadata.read`), `TransactionOrchestrator` op `object.create` (атомарный post+insert в одной пачке, `prepare_object_create`, `update_batch` с insert-маркером `version == 0`), конструктор `TransactionOrchestrator::new(objects, metadata)`; 3 call-site теста | §1–§2, §5, §5е, §5и, §6, §7 |
| `6239dd4` | 2026-09-13 | chore(clippy): тривиальные предупреждения Фазы 13 — `clone_on_copy` (ScriptType в module_manager), `needless_question_mark` (rhai_core_api), `unwrap_or` (extism_wasm_host); clippy снова чист кроме 2 pre-existing «too many arguments» (конструкторы ModuleManager/ExtismWasmHost) | §6, §7 |
| `f2d6975` | 2026-09-13 | **Фаза 13 (доработка):** рефакторинг `CommandHandler` → `Fn(Value, CommandExecutionCtx)` (актор в команды, ~69 точек), политика `platform.scripts` (seed, `script.manage`/`script.execute`/`script.read`, priority 90), `ScriptContext.args`, `script_runner::execute_script` (валидации execute), команды `script.get`/`script.validate`/`script.execute`, `script.list` → `script.read`, проброс движка в `register_phase13_commands`; интеграционные тесты `phase13_scripts` (+5), всего 210 | §1–§2, §6, §7 |
| `1074d29` | 2026-09-13 | **Фаза 13:** Rhai-скриптовый движок — `RhaiScriptEngine` (песочница, таймаут, кэш AST) + Core API (`log_info`/`log_error`/`emit_event`/`emit_transaction`/`db_query` через `await_core_api`), `ScriptRepository` (SurrealDB), модель `Script`, `ScriptContext`, манифестные скрипты, host-fn `run_script` — реальная (вместо заглушки 9c), команды `script.*`; фикс блокировки воркера tokio (std `recv_timeout` → `tokio::sync::mpsc` + `time::timeout`); тесты 113 | §1–§2, §5, §6 |
| `0a92266` | 2026-09-05 | Каркас, слои ядра, регистры | §3–§5 |
| `225c8c2` | 2026-09-05 | SurrealDB Event Store + debug REST | §2, §5а, §6–§8 |
| `cc63516` | 2026-09-05 | Уточнение правила снимка (AGENTS §2.5) | — |
| `221d308` | 2026-09-05 | Актуализация контекста проекта (AGENTS §8–§18, структура) | — |
| `f428bc1` | 2026-09-05 | Фаза 2: модели, репозитории, команды, live-верификация | §2, §4–§8 |
| `53fef25` | 2026-09-05 | Актуализация §8 ТЗ (типы потоков, метаданные актора) | — |
| `f485412` | 2026-09-05 | Возврат описания ActorSnapshot в ТЗ к исходному (по требованию) | — |
| `0329371` | 2026-09-05 | `ActorSnapshot` в коде по ТЗ: position/company_id, system() | §4, §6 |
| `7296772` | 2026-09-06 | Фаза 3: метаданные (entity_types/fields/states/transitions/forms/actions/relations) + live-проверка | §2, §4, §5, §5б, §6, §7 |
| `450346a` | 2026-09-06 | Фаза 4: объекты (CRUD, OCC, снимки версий, нумерация документов) + live-проверка | §1–§2, §4, §5, §5г, §6, §7 |
| `f7e86b9` | 2026-09-06 | Перевод всех комментариев на русский (25 файлов) + AGENTS §11 + ТЗ v3.1 | §1 |
| `3966cfc` | 2026-09-07 | Актуализация AGENTS под ТЗ v3.1 (фазы аудита/прав, глоссарий, ADR-011..013) | — |
| `5ed7dbb` | 2026-09-07 | Фаза 4: аудит действий (audit_log), AuditRepository, 2 команды, live-проверка | §1–§2, §4, §5, §5д, §6, §7 |
| `65ee830` | 2026-09-07 | Фаза 5: RBAC — PermissionManager, CommandExecutionPipeline, системные роли/политики, миграция всех команд, role.seed/system.migrate_permissions, live-проверка | §1–§2, §4, §5, §5б, §6, §7 |
| `5d2f89b` | 2026-09-07 | AGENTS §15: Фазы 4 (аудит) и 5 (RBAC) в истории разработки | §2 (примечание о порядке выполнения), §5г |
| `44852b5` | 2026-09-07 | Синхронизация документов: AGENTS §12 (порты/репозитории Фаз 4-5), нумерация фаз §2, тесты 95, команды 31, ролевой трейт, WasmHost | §1–§2, §5, §5б, §5д, §6–§8 |
| `79551d0` | 2026-09-08 | Удаление автономной утилиты `surreal-tui` (не член workspace) | §8 |
| `11721c6` | 2026-09-08 | Фаза 9 подфаза 8a: WASM-хост Extism, манифест v2, ModuleKv, host-fn 8a, hello_plugin | §1–§2, §5, §8 |
| `7c6382a` | 2026-09-08 | Фаза 9 подфаза 8b: `ObjectRepository::count` (пагинация, total_count) | §2, §5 |
| `3d9e614` | 2026-09-08 | Фаза 9 подфаза 8b: host-fn 8b (objects.*/metadata.*), фикстура с objects_probe, интеграционные тесты | §1–§2, §5, §8 |
| `3669e30` | 2026-09-08 | AGENTS: переработка под актуальную структуру и стадии ТЗ | — |
| `6887aed` | 2026-09-08 | Фаза 9: коды конверта host-fn по Прил. №6 ТЗ (NOT_FOUND/INVALID_UUID/CONFLICT_ERROR), пробы update/get/list в плагине, тесты | §1–§2, §5, §8 |
| `9d79db7` | 2026-09-08 | Фаза 9: live-проверка WASM-хоста на сервере — debug-REST `/debug/modules`, `/debug/module/load`, `/debug/module/invoke`; проверено на живом SurrealDB (KV, объекты, OCC CONFLICT_ERROR) | §1–§2, §5, §8 |
| `11bbc43` | 2026-09-09 | Фаза 9 подфаза 9b: ModuleStore (modules + company_modules), ModuleManager с декларативной регистрацией (политики/схемы/команды `plugin.*`), команды `module.*` (~cache), WasmHost/MetadataRepository → BoxFuture, тесты 123, live-цикл hello | §2, §5, §5е, §6 |
| `a64a565` | 2026-09-09 | Фаза 9 подфаза 9c: реальная host-fn `emit_event` (cap `events.emit`, коды Прил. №6), заглушки `run_script`/`notify_user`/`users_by_role`/`signature_required`/`cms_verify`, reinstall — первоклассная операция (`module.reinstalled` + аудит «кто» через events-metadata/audit-актор, до auth — `ActorSnapshot::system()`), hello_plugin `mod host`, тесты 127, live-цикл 9c на живом SurrealDB | §2, §5, §5е, §5ж, §7 |
| `f3c04e8` | 2026-09-08 | Версия workspace `3.0.1` (по ТЗ v3.1): Cargo.toml, Cargo.lock, баннер сервера | §1 |
| `55b706c` | 2026-09-09 | Фаза 9 подфаза 9d: локальный `.cargo/config` + `lld-wrapper.sh` для wasm32 (отсечение `-fuse-ld=*`), экспорт `users_probe`, пересобранная фикстура hello.wasm, AGENTS §«Сборка WASM-фикстуры» | §2, §5ж |
| `94eaa13` | 2026-09-09 | Фаза 9 подфаза 9d: реальная host-fn `users_by_role` — порт `UserRepository::list_by_role` (гейт по компании роли), обогащение person/email, 4 теста hello_wasm | §1–§2, §5, §5з, §7 |
| `ee9fa52` | 2026-09-09 | Фаза 9 подфаза 9d: `preload_company_modules` — `ModuleRepository::list_enabled_companies` + `ModuleManager::preload_all` (кэш `{code}-{wasm_sha256}.wasm`, идемпотентная регистрация, нефатальные ошибки), вызов в main.rs, 3 теста phase9d_preload | §1–§2, §5, §5з, §6, §7 |
| `03e9833` | 2026-09-10 | Фаза 9 tx_exec: `ObjectRepository::update_batch` — атомарная пачка (load→OCC→write+snapshot, единый assign_versions+write_events, rollback всей пачки при сбое); ObjectRepository переведён на BoxFuture (trait-object) | §1–§2, §5, §5и |
| `95eae7c` | 2026-09-10 | Фаза 9 tx_exec: `TransactionOrchestrator` (begin/add_op/commit, `$ref`-связывание, идемпотентность по business_key, GC 60с/TTL 5мин, prepare_object_op с OCC и гейтом по компании) + 8 unit-тестов | §1–§2, §5, §5и |
| `e41ea21` | 2026-09-10 | Фаза 9 tx_exec: host-fn `tx_begin`/`tx_add_op`/`tx_commit` в ExtismWasmHost (capability `transactions`, namespace ExtismHost), вызов оркестратора в main.rs | §1–§2, §5, §5и |
| `6b84b4d` | 2026-09-10 | Фаза 9 tx_exec: hello_plugin — foreign-fn tx_*, экспорты `tx_probe`/`tx_ref_probe`/`tx_idem_probe`, capability `transactions` в манифест, пересобранная фикстура hello.wasm | §2, §5и |
| `2646256` | 2026-09-10 | Фаза 9 tx_exec: интеграционные тесты hello_wasm (+5, всего 19) — успешный коммит, `$ref`, идемпотентность, отказ без capability, конфликт версий CONFLICT_ERROR | §2, §5и, §7 |
| `d661f28` | 2026-09-10 | Фаза 9 tx_exec: AGENTS §статус фаз — Фаза 9 завершена; технический отчёт §1/§2/§5и/§8 | §1–§2, §5и, §8 |
| `80890fb` | 2026-09-10 | Фаза 9 tx_exec: перенос HashSet-импорта в тестовый модуль surreal_module_repository (clippy) | §5и |
| `b49495f` | 2026-09-10 | Фаза 10a: RpcMessage-конверт + `POST /rpc` (core-api: rpc_message/error_mapping/idempotency/routes), типизированные ошибки команд (CommandRegistry → DomainError), `EventStore` → BoxFuture (object-safe), идемпотентность Command, legacy-конверт, тесты 166 | §1–§2, §5, §6 |
| `dd1f779` | 2026-09-11 | Фаза 10b: JWT-аутентификация — `user.login`/`user.logout`, `AuthService` + порт `TokenManager`, `JwtTokenManager` (jsonwebtoken 9), Argon2id-пароли (core-domain `password.rs`, `user.create`/`user.update` → `password`), блокировка 5×15 мин, аудит `user.login`/`user.login_failed`/`user.logout`, фикс RBAC для анонимов, `Authorization: Bearer` в `/rpc`, тесты 180 | §1–§2, §5, §6 |
| `79e9390` | 2026-09-11 | Фаза 10c: WebSocket/ServerPush — `PushHub` (broadcast 256), `GET /ws` (`ws_handler`/`ws_session`, актор из `?token=`, общий `process()`, ServerPush по каналу), рефакторинг `routes.rs` (`process`/`respond`/`http_status_for_code`), `POST /debug/push`, тесты 185 | §1–§2, §5, §6, §7 |
| `7d80a9c` | 2026-09-11 | Актуализация AGENTS.md под снимки фаз: Фазы 1–8 в статусе, JWT/core-api/тесты в ключевых файлах и командах, фикс подфазы TransactionOrchestrator 9d→9e | — |
| `b5dd060` | 2026-09-11 | Фаза 10c (фикс): утечка writer-задачи при закрытии WS-сессии — явный `None` из `out_rx.recv()` завершает `select!` (ветка `Some(msg)` ранее отключалась, `else` был недостижим из-за вечного `push_rx`), ответный `Close(None)` на `Message::Close` для корректного рукопожатия RFC 6455; тесты 185 | §5, §7 |

---

## 2. Реализованные фазы

| ID | Фаза | Статус | Комментарий | Коммит |
|---|---|---|---|---|
| 1 | Каркас проекта: слои ядра, web-сервер, graceful shutdown | ✅ Done | core-domain / core-application, Axum 0.8, `/health`, dotenvy, tracing | `0a92266` |
| 8 | CommandRegistry, AppRegistry, 5 регистров | ✅ Done | с ensure-семантикой и тестами (по AGENTS §15 — Фаза 8) | `0a92266` |
| 7 | События: SurrealDB Event Store (Труба) | ✅ Done | `SurrealEventStore`, индексы, идемпотентный append, debug REST (по AGENTS §15 — Фаза 7) | `225c8c2` |
| 2 | Компании, пользователи, роли | ✅ Done | модели + репозитории «Доска+Труба» + 12 команд + live-проверка | `f428bc1` |
| 3 | Метаданные: entity_types, fields, states, transitions, forms, relations, actions | ✅ Done | модели + `MetadataRepository` + ensure по `metadata_version` + 6 команд + live-проверка | `7296772` |
| 6 | Объекты, CRUD, оптимистичная блокировка | ✅ Done | `ObjectRepository` + OCC по `version` + снимки + атомарная нумерация + 8 команд + live-проверка (по AGENTS §15 — Фаза 6) | `450346a` |
| 4 | Аудит действий (audit_log) (ТЗ v3.1) | ✅ Done | `AuditRepository` + 5 индексов + `audit.log`/`audit.query` + live-проверка | `5ed7dbb` |
| 5 | Права доступа (RBAC) (ТЗ v3.1) | ✅ Done | `PermissionManager` + `CommandExecutionPipeline` + системные роли/политики + `role.seed`/`system.migrate_permissions` + live-проверка | `65ee830` |
| 9 (8b) | WASM-хостинг (Extism), манифест v2, host-fn 8a–8b | ✅ Done | `WasmHost`-порт, `ExtismWasmHost`, `ModuleKv`, host-fn 8b (objects.*/metadata.*, `ObjectRepository::count`), коды конверта по Прил. №6, debug-REST `/debug/modules|module/load|module/invoke` + live-проверка, пример `hello_plugin` + интеграционные тесты (по AGENTS §15 — Фаза 9) | `9d79db7` |
| 9 (9b) | ModuleStore + декларативная регистрация (Фаза 9) | ✅ Done | каталог `modules` + проекция `company_modules`, `ModuleManager` (политики/схемы/команды `plugin.*` по манифесту), команды `module.install/uninstall/enable/disable/list/info` (`module.manage`), кэш модулей, тесты 123, live-цикл hello | `11bbc43` |
| 9 (9c) | host-fn 9c: `emit_event` + заглушки, reinstall (Фаза 9) | ✅ Done | реальная `emit_event` (cap `events.emit`, коды Прил. №6), заглушки `run_script`/`notify_user`/`users_by_role`/`signature_required`/`cms_verify`, **reinstall — первоклассная операция** (`module.reinstalled` + аудит «кто»), тесты 127, live-цикл 9c | `a64a565` |
| 9 (9d) | реальный `users_by_role` + `preload_company_modules` (Фаза 9) | ✅ Done | **реальная** host-fn `users_by_role` (порт `list_by_role`, гейт по компании роли, обогащение person/email), `ModuleManager::preload_all` при старте (кэш `{code}-{wasm_sha256}.wasm`, идемпотентная регистрация, нефатальные ошибки), локальный `.cargo/config` с обёрткой линкера, тесты 138 | `ee9fa52` |
| 9 (9e) | транзакционная оркестрация `tx_exec` (Фаза 9, §9 ТЗ) | ✅ Done | `TransactionOrchestrator` (begin/add_op/commit, `$ref`-связывание с лимитом глубины 10, идемпотентность по business_key, GC 60с/TTL 5мин), host-fn `tx_begin`/`tx_add_op`/`tx_commit` (cap `transactions`), `ObjectRepository::update_batch` (атомарная пачка, rollback при сбое, OCC), операции `object.post`/`object.cancel`/`test.noop`, hello_plugin пробы, тесты 153 | `d661f28` |
| 10 (10a) | транспортный слой RpcMessage (ТЗ v3.1 §10) | ✅ Done | конверт `RpcMessage` + `POST /rpc` (`core-api`), типизированные ошибки команд (`CommandRegistry` → `DomainError`), коды `RpcMessage::Error`/HTTP-статусы, идемпотентность Command (TTL 5 мин, GC 60 с), `EventStore` → BoxFuture (object-safe), legacy-конверт `/debug/command`, интеграционные тесты phase10a_rpc (10), тесты 166 | `b49495f` |
| 10 (10b) | аутентификация JWT + логин (ТЗ v3.1 §10) | ✅ Done | `user.login`/`user.logout` + `AuthService` (`auth.rs`) + порт `TokenManager` (`AuthToken`), `JwtTokenManager` (`token.rs`, jsonwebtoken 9, HS256), Argon2id-пароли (`core-domain/password.rs`, `user.create`/`user.update` → `password`), аудит `user.login`/`user.login_failed`/`user.logout`, блокировка 5 и более попыток на 15 мин (`locked_until`), `Authorization: Bearer` в `/rpc` → актор, `IdempotencyKey` с actor_user_id, фикс RBAC (аноним без токена → PERMISSION_ERROR), интеграционные тесты phase10b_auth_rpc (8), тесты 180 | `dd1f779` |
| 10 (10c) | WebSocket/ServerPush (ТЗ v3.1 §10) | ✅ Done | `PushHub` (broadcast 256), `GET /ws` (`ws_handler`/`ws_session`, актор из `Query?token=<JWT>`, общий `process()` для REST/WS, ServerPush по каналу исходящих, select между сокетом и хабом), рефакторинг `routes.rs` (`process`/`respond`/`http_status_for_code`), `POST /debug/push`, юнит-тесты push_hub (2), интеграционные тесты phase10c_ws (3), тесты 185 | `b5dd060` |
| 13 | Скрипты Rhai (ТЗ v3.1 §15) | ✅ Done | `RhaiScriptEngine` (песочница, таймаут, кэш AST), Core API (`log_info`/`log_error`/`emit_event`/`emit_transaction`/`db_query` через `await_core_api`), `ScriptRepository` + модель `Script` + `ScriptContext` (вкл. `args`), манифестные скрипты в `ModuleManifest`, host-fn `run_script` — реальная (была заглушка 9c), политика `platform.scripts` (seed, namespaced actions, без ролей), `CommandHandler` → `Fn(Value, CommandExecutionCtx)`, `script_runner::execute_script` (валидации execute), команды `script.create/update/delete` (`script.manage`), `script.list/get/validate` (`script.read`), `script.execute` (`script.execute`); фикс блокировки воркера; тесты 210 | `f2d6975` |
| 14 | Модуль управленческого учёта (ТЗ v3.1 §14) | ✅ Done | `plugin.accounting`: платформенная поддержка (манифестные команды с `function` — WASM-экспорт подчёркиванием, `ManifestField.options` для enum, host-fn `get_entity_type_by_code`, op `object.create` в транзакциях, `TransactionOrchestrator::new(objects, metadata)`); модуль `examples/accounting_plugin` (13 команд: account.*, period.*, entry.*, doc.post, balance.trial/sheet; 3 схемы; permissions accounting.manage/read/post; контракт `{company_id, input}`), фикстура `accounting.wasm`, формы проводок только дебет=кредит, сторно — обратные записи, учётные периоды; интеграционные тесты `phase14_accounting` (12), всего тестов 223; live-цикл /rpc + Bearer JWT | `c42f95c` |
| 11b-prep | Доработка перед 11б: SDUI-навигация модулей | ✅ Done | политика `platform.modules` (`module.read`, ByCompany, p40) + привязка staff/guest; `seed_system_roles_and_policies` → `SeedSummary` + дополнение существующих ролей; `RoleRepository::update`; `ManifestNavItem.entity_type`; `ModuleManager::get_navigation`; команда `module.navigation` (`module.read`); `system.migrate_permissions` → `{companies_total, seeded, policies_added}` для всех компаний; навигация `accounting_plugin` + пересобранный `accounting.wasm`; интеграционные тесты `phase11_navigation` (8), тестов 251 | `bfa782e` |
| A | system.bootstrap — однократная инициализация платформы | ✅ Done | `core-application/bootstrap.rs` `bootstrap_platform` (идемпотентность: коллизия кода → «Компания {code} уже существует», непустая БД → «Платформа уже инициализирована»; компания → суперадмин Argon2id → сид → привязка роли + primary-профиль → аудит `system.bootstrap`); команда `system.bootstrap` (`requires("system.bootstrap")` — только системный актор `/debug/command`); warn при старте если пусто; интеграционные тесты `phase_bootstrap` (6) | `7ac3aca` |
| 15pre-1 | Системные метаданные (ТЗ v3.1_1 §2) | ✅ Done | `metadata_seed.rs` — `seed_system_metadata` засевает 7 системных типов (`company`/`user`/`role`/`entity_type`/`entity_field`/`entity_state`/`entity_transition`, `is_system=true`, `company_id=""`, события `metadata.seeded`); вызов из `bootstrap_platform` (generic `M: MetadataRepository`, после сида ролей), `BootstrapResult.metadata_entity_types_seeded`; повторный bootstrap не дублирует (ensure-семантика); тесты `phase_bootstrap` расширены (6) | `9646899` |
| 15pre-2 | SDUI ядровых сущностей (ТЗ v3.1_1 §2) | ✅ Done | делегация `object.create/get/list/update` для `company`/`user`/`role` (маппинг в универсальную форму `{id, entity_type, kind, company_id, state, data}`, генерация событий `company.created`/`user.created`/`role.created` и т.д., фильтр списков по компании через роли пользователя); synthetic-модуль `platform` в `ModuleManager::get_navigation` (гейт — права `read`); global-fallback системных схем (`get_entity_type_by_code` из `company_id=""` только для `is_system`); клиент рендерит ядровые типы без изменения wire-контракта; юнит-тесты сервера 5 (`commands.rs`), клиентские 9 (`home_screen_test` 5 + `core_entity_catalog_test` 4); флатер 121/121 | `2a837d6` |
| 15pre-3 | Редактор метаданных + экспорт/импорт (ТЗ v3.1_1 §2) | ✅ Done | `MetadataRepository::export_entity_type`/`import_entity_type` (surreal: экспорт схема→JSON, импорт `from_value::<EntitySchema>`+`create_entity_type`, событие `metadata.entity_type.imported`); orphan-синхронизация `delete_orphans` (после апсёрта дочерних ресурсов, удалённые в схеме поля/переходы уходят из БД); команды `metadata.export` (`metadata.read`) / `metadata.import` (`metadata.manage`), wire-контракт `{entity_type, fields[], states[], transitions[], forms[], actions[], relations[]}` с обязательным `metadata_version` (ensure: старшая применяется, ≤ — no-op); пункт «Метаданные» в `module.navigation` за `metadata.manage`; клиент: `toJson/copyWith` моделей, `MetadataService` (create/export/import со сбросом кэша), SDUI-редактор `metadata_editor_screen` (секции Поля/Состояния/Переходы, диалоги добавления/редактирования, каскадное удаление переходов, guard последнего состояния, бамп `metadata_version` при сохранении, экспорт/импорт JSON, «Новый тип»), роут `/metadata/editor/:entityType?`; тесты: clippy 0, сервер 45 (7+12+8+6+12), клиент 131 (121+10) | `5caf46f` |
| 15.1 | Скрипты Rhai — отладка и валидация (ТЗ v3.1 §15/§19) | ✅ Done | `script.test` (`script.manage`): test_script — тестовый прогон без гейтов `is_active`/`object`, `{result, execution_time_ms}`; `script.validate` (`script.read`): структурированный контракт `{valid, errors:[{line,column,message}]}` по `source`/`code`, bind-проверка entity_type через MetadataRepository; `DomainError::ScriptFailure{message,line,column}` (VALIDATION_ERROR, HTTP 422 + error_details) и `ScriptError` (core-domain), координаты из rhai position()/line(); Extism ValidationError|ScriptFailure → INVALID_ACTION; тесты phase13_scripts 13, platform-server 7, clippy 0 | `38180e4` |
| 15.2 | Клиентский каталог скриптов (ТЗ v3.1 §15) | ✅ Done | клиент: `ScriptItem`, `ScriptService` list/get/create/update/delete/validate/testRun, `scriptsProvider`; `ScriptListScreen` `/scripts` (DataTable + типы + статусы, FAB, RefreshIndicator); `ScriptEditorScreen` `/scripts/new`+`/scripts/:code/edit` (форма, «Проверить»=validate, «Прогнать»=test, панель ошибок с координатами); пункт «Скрипты» в навигации за `script.manage`; сервер: `get_navigation` → scripts, phase11_navigation 8/8 (admin видит, staff — нет); клиентские тесты 159 (4 файла + home-кейс), analyzer 0, clippy 0 | `772bd07` |
| 15.3 | Rhai-редактор: подсветка + пре-чек «;» (ТЗ v3.1 §15) | ✅ Done | клиент: `core/rhai_grammar.dart` (Mode из rust.dart, flutter_highlight фоном + прозрачный TextField, тема из colorScheme, `registerRhaiHighlight`), `core/rhai_precheck.dart` (консервативный пре-чек незавершённых операторов), Switch «strict „;"» (блокирует сохранение с координатой в SnackBar), панель «Клиентский пре-чек:»; +11 тестов (precheck 10, editor 3) → 172, analyzer 0 | `e7e6c68` |
| 15.4 | Авто-хук скриптов в object-конвейер (ТЗ v3.1 §15) | ✅ Done | `core-application/script_hooks.rs` — `object_pre_hooks` (formula → validator → before_action) и `object_after_hooks` (after_action); формула (Rhai-map) мержится в `object.computed` до валидации схемы, validator `false` → ValidationError, before/after прерывают команду (после записи объект уже в БД); привязка `is_active`+`entity_type`, компания (компания+глобальные / только глобальные); встроено в `object.create`/`object.update` (actor из ctx с фолбэком system); +2 теста (после regression-фикса `1316fed` engine_blocks_fs_access→ScriptFailure), object_-тесты 7/7, полный `cargo test --workspace` PASS (24+51+83+20+8+13+12+10+6+3+6+8+10+8+3+9), clippy 0 | `2bcf6d0` |

> **Примечание о порядке выполнения:**
> Фазы выполнялись не строго по порядку ТЗ v3.1. Объекты (Фаза 6) реализованы до
> аудита (Фаза 4) и прав (Фаза 5). `CommandExecutionPipeline` (Фаза 5) автоматически
> применяется ко всем существующим командам, включая объекты.

> **Примечания к Фазе 5 (ретроспектива):**
> - Отладочный `POST /debug/command` при отказе прав возвращает тело ошибки **строкой**
>   (`"Недостаточно прав: недостаточно прав на команду role.list"`, HTTP 400), а не
>   JSON-конвертом. Для единообразного клиентского разбора стоит привести ответ к виду
>   `{"ok": false, "error": "...", "error_code": "PERMISSION_ERROR"}` — планируется к
>   реализации в Фазе 10 (транспортный слой `RpcMessage`, REST + WebSocket).
> - Проверка прав и аудит встроены в pipeline, поэтому на высокой частоте команд
>   добавляются 2 записи `audit_log` на каждое действие (started + finished/denied);
>   при необходимости допустимо поднять порог `level` для `audit.log` или
>   агрегировать `started`-записи (вопрос к ТЗ §8.5, retention).
> - Роли привязаны к компании (`(company_id, code) UNIQUE`), политики — глобальные.
>   Миграция компаний, созданных до Фазы 5, — `system.migrate_permissions` (идемпотентна).

---

## 3. Структура workspace

```text
2C/
├── Cargo.toml              # workspace: crates/* + apps/platform-server
├── rust-toolchain.toml     # channel = "1.96.0"
├── crates/
│   ├── core-domain/        # чистый домен (модули, см. §4)
│   ├── core-application/   # оркестрация: порты + регистры (см. §5)
│   ├── core-infrastructure/# SurrealDB Event Store (см. §5а)
│   └── core-api/           # транспорт Axum/WS/RpcMessage (каркас)
├── apps/
│   └── platform-server/    # бинарник: /health, debug REST, graceful shutdown
└── examples/
    └── hello_plugin/       # пример WASM-модуля (вне workspace, wasm32-unknown-unknown)
```

---

## 4. core-domain — чистый домен

Не зависит от БД, фреймворков и tokio (проверено `cargo tree`).
Ошибки — `Result`-тип. Нет заглушек и `.unwrap()` в продакшн-коде.

| Модуль | Содержимое |
|---|---|
| `types.rs` | `AggregateId = Uuid`, `Version = u64` |
| `event.rs` | `StreamType` (10 видов: object/user/person/user_contact/user_profile/user_cert/company/role/module/metadata), `Event`, `ActorSnapshot` + `system()` |
| `command.rs` | `Command { id, module, action, payload }` |
| `object.rs` | `Object`, `ObjectKind` (8 видов), `ObjectSnapshot`, `Object::validate`/`is_document` по разделу 7 ТЗ |
| `company.rs` | `Company { id, code, name, is_active, created_at, updated_at }` (Фаза 2) |
| `role.rs` | `Role { id, company_id, code, name, description, permission_policy_codes, is_system, created_at, updated_at }` (Фазы 2/5) |
| `metadata.rs` | `EntityType`, `EntityField`, `EntityState`, `EntityTransition`, `EntityForm`, `EntityAction`, `EntityRelation`, `FieldType` (17), `RelationKind`, `OnDelete`; `EntityKind = ObjectKind` (Фаза 3) |
| `user.rs` | `User`, `Person`, `UserContact`, `UserCompanyProfile`, `UserCertificate` + `UserStatus`/`ContactChannelType`/`ContactPurpose` (Фаза 2) |
| `aggregate.rs` | `AggregateRoot`: OCC-проверка последовательности событий |
| `audit.rs` | `AuditEntry`, `AuditTarget`, `AuditResult`, `AuditFilter` (Фаза 4, ТЗ §8.5/Прил. №6); аудит — отдельная подсистема от Event Store |
| `permission.rs` | `PermissionPolicy { id, code, name, scope_type, entity_type, actions, record_access, deny, priority, is_system }`, `PermissionScopeType` (Platform/Module/Metadata/None), `RecordAccessLevel` (Owned/ByRole/ByCompany/All) (Фаза 5, Прил. №7) |
| `error.rs` | `DomainError`: NotFound, VersionConflict, ValidationError, PermissionDenied, Storage + `code()`; `PermissionDenied` → `PERMISSION_ERROR` |

### Ошибки → коды RpcMessage::Error

| Вариант DomainError | code() |
|---|---|
| NotFound | `NOT_FOUND_ERROR` |
| VersionConflict | `CONFLICT_ERROR` |
| ValidationError | `VALIDATION_ERROR` |
| PermissionDenied | `PERMISSION_ERROR` |
| Storage | `STORAGE_ERROR` |

### Оптимистичный контроль

`AggregateRoot::apply` проверяет `expected = version + pending.len() + 1` при
каждом событии; при расхождении возвращает `VersionConflict` и событие отбрасывается.
Охвачено тестами (в порядке / out-of-order).

---

## 5. core-application — оркестрация

Зависит от `core-domain`, tokio, serde_json. `async fn` в трейтах десугаризованы
в `impl Future + Send` (снят lint `async_fn_in_trait`).

### Порты (порт AB.I)

| Порт | Методы | Заметки |
|---|---|---|
| `EventStore` | `append(&[Event])`, `read_stream(StreamType, &str)` | append идемпотентен по ID события |
| `ObjectRepository` | `get`, `create(&Object,&[Event])→Object`, `update(&Object,&[Event])→Object` (OCC по `obj.version`), `delete`, `list`, `get_snapshots`, `restore_snapshot`, `next_document_number` | write-методы атомарно пишут объект + снимок + события |
| `WasmHost` | `load_module(code, wasm)`→`ModuleManifest`, `call_function(code, fn, input)`→`Vec<u8>`, `unload_module(code)`, `is_loaded(code)` | манифест v2 + host-fn 8a в namespace `ExtismHost`; реализация — `ExtismWasmHost` в `core-infrastructure` |
| `CompanyRepository` | `create/get/list/update` | write-методы принимают `&[Event]` (атомарно Доска+Труба) |
| `UserRepository` | `create/get/list/update`, `add_contact`, `add_profile` | idem, транзакции в `surreal_user_repository` |
| `RoleRepository` | `create`, `get`, `get_by_code(company_id, code)`, `update`, `list`, `get_policies_for_user(user_id, company_id)` | idem; уникальность `(company_id, code)`; `update` — транзакционная дозапись политик (Доска+Труба, событие `role.updated`), добавлен в доработке перед 11б (Фаза 5 убрала `list_by_company`, добавила `get_policies_for_user`) |
| `PermissionPolicyRepository` | `upsert` (ensure по `code`), `get_by_code`, `get_by_codes` | политики глобальны (не привязаны к компании); UNIQUE `code` (Фаза 5) |
| `MetadataRepository` | `create_entity_type/get_entity_type/get_entity_type_by_code/list_entity_types/update_entity_type/get_schema` | ensure по `metadata_version`; `EntitySchema` — полный снимок типа |
| `AuditRepository` | `log(AuditEntry)`, `query(AuditFilter) → Vec<AuditEntry>` | append-only; выборка в порядке убывания `timestamp`; фильтры по action/actor/company/time/result |

### Конвейер прав (Фаза 5)

- **`PermissionManager`** — `check_access(policies, module_code, entity_type, action)`:
  фильтрация по scope/entity/actions → сортировка `priority` по убыванию → решает
  первая совпавшая политика (`deny` = запрет, иначе разрешение);
  нет совпадений → **deny-by-default**.
- **`CommandExecutionPipeline`** — оборачивает `CommandRegistry::execute`: при каждом
  вызове с `actor` пишет в аудит `command.executed` (stage=started), проверяет
  `PermissionManager::check` по `required_permission` команды, при отказе →
  `permission.denied` (Failure) + `DomainError::PermissionDenied`, иначе исполняет
  handler и пишет `finished`/`failed`. Системный исполнитель (actor=None) — bypass.
- **`CommandMetadata`** — `requires(action)`; каждая команда декларирует одно
  действие: бизнес — `create`/`read`/`update`/`delete`, системные сущности —
  `role.manage` / `metadata.manage` / `metadata.read` / `audit.read`.
- **`seed.rs`** — `seed_system_roles_and_policies(company_id, roles, policies, audit)`:
  идемпотентный сид 4 ролей (`admin`→`platform.full`, `staff`, `guest`, `archived`)
  и 6 политик (`platform.full` actions `["*"]` priority 100, `staff.objects`
  `["create","read","update"]` priority 50, `guest.objects` `["read"]` priority 40,
  `archived.objects` `[]` priority 40, `platform.scripts` `["script.manage",
  "script.execute","script.read"]` priority 90, `platform.modules` `["module.read"]`
  ByCompany priority 40 — добавлена в доработке перед 11б и привязана к `staff`/`guest`).
  Возвращает `SeedSummary{roles_created, policies_added}` и дополняет существующие
  системные роли недостающими политиками через `RoleRepository::update`. Старые
  компании лечит `system.migrate_permissions` — сидит **все** компании (уже
  созданные роли дополняются политиками), аудит `system.migrate_permissions` с
  `{companies_total, seeded, policies_added}`, идемпотентен.

### Регистры (Приложения №1 и №2 ТЗ)

- **CommandRegistry** — `RwLock<HashMap<String, Arc<dyn Fn…>>>`;
  `register`/`unregister`/`execute`/`list`/`remove_by_prefix` (для удаления модуля,
  префикс `plugin.{code}.`).
- **CodeRegistry** — `RwLock<HashSet<String>>`; идемпотентный `ensure` по кодам;
  `remove`/`contains`/`list`. Применяется 4 раза.
- **AppRegistry** — 5 регистров: CommandRegistry + 4 × CodeRegistry
  (permissions, object_schemas, print_templates, scripts);
  `register_module` (ensure-семантика), `unregister_module` (очистка включ. команд)
  и `preload_metadata_to_registry(schemas)` — декларация entity_type.code в
  object_schemas (API для прелоадера модулей Фазы 9).

---

## 5а. core-infrastructure — SurrealDB Event Store (Труба)

Реализует порт `EventStore` (фаза 5). Зависит от `core-application`/`core-domain`,
surrealdb 3.2.4 (WS-протокол). В dev-dependencies — kv-mem (для тестов).

| Компонент | Реализация |
|---|---|
| `SurrealEventStore::connect(host,user,pass,ns,db)` | WS-подключение, `signin Root`, `use_ns/use_db` |
| `ensure_schema()` | 4 индекса «IF NOT EXISTS»: stream, type_time, company_time, correlation |
| `append(&[Event])` | идемпотентный UPSERT по id события (`db.upsert(("events", id)).content(json)`) |
| `read_stream(type, id)` | SELECT с фильтром и `ORDER BY version ASC`, декод через serde_json |

**Ключевые инженерные находки:**
- Raw-SQL `UPDATE type::record($id)` / интерполяция `events:<uuid>` не работают:
  дефисы в UUID ломают парсинг record-id. Рабочее решение — типизированный
  builder `db.upsert(("events", uuid)).content(serde_json::Value)`.
- В SurrealQL `$type` — зарезервированная встроенная переменная; для фильтра
  используются `$stream_type`/`$stream_id`.
- SurrealDB 3.2: функция переименована `type::thing` → `type::record`.
- `mem://`-движок общий для всех тестов в процессе → изоляция через уникальную DB
  на каждый тест (`Uuid`).

Реализация: `crates/core-infrastructure/src/surreal_event_store.rs`, 4 теста
(схема, идемпотентность, фильтрация, порядок версий).

## 5б. core-infrastructure — репозитории «Доска» (Фаза 2)

Репозитории реализуют порты Фазы 2 и пишут атомарно в коллекцию («Доска») и в
Event Store («Труба») внутри одной SurrealDB-транзакции. Общие хелперы вынесены
в `events.rs`:

| Модуль | Функция | Назначение |
|---|---|---|
| `connector.rs` | `connect_db(host,user,pass,ns,db)` | единая WS-сессия `Surreal<Any>` |
| `events.rs` | `event_record(&Event)` → `serde_json::Value` | сериализация события в запись |
| `events.rs` | `append_events(db, events)` | идемпотентный UPSERT событий |
| `events.rs` | `assign_versions(events)` | выставление `version` per-stream одним проходом |
| `events.rs` | `write_events(Transaction, events)` | запись событий и последней версии в атомарной транзакции |
| `events.rs` | `with_transaction(db, \|txn\| …)` | рамки: begin → closure(owning txn) → commit/rollback; обобщена по типу результата `Result<O, _>` (Фаза 4) |

| Репозиторий | ensure_schema | Транзакционные операции |
|---|---|---|
| `surreal_company_repository.rs` | `companies` + UNIQUE `code` | create/get/list/update |
| `surreal_user_repository.rs` | `users` (UNIQUE `login`), `persons`, `user_contacts`, `user_company_profiles`, `user_certificates` | create (user+person), get/list, update, add_contact, add_profile |
| `surreal_role_repository.rs` | `roles` + UNIQUE `(company_id, code)` (миграция индекса `idx_roles_code` → `idx_roles_company_code`) | create (транзакция, дубль по `(company_id, code)`), get/get_by_code/list, get_policies_for_user (users.role_ids → roles → sort+dedup); поля `permission_policy_codes`/`is_system` (Фаза 5) |
| `surreal_permission_policy_repository.rs` | `permission_policies` + UNIQUE `code` | upsert = ensure по коду (SELECT→CREATE; существующая политика не перезаписывается), get_by_code/get_by_codes |

**Ключевые инженерные находки (Фаза 2):**
- Транзакция в surrealdb 3.2.4: `begin(self)` потребляет `&self` →
  нужен `db.clone().begin()`. `Transaction<Any>` живёт в `transaction.rs`.
- HRTB при `impl FnOnce(&mut txn)` не проходит для borrow `Transaction<Any>`;
  использован owned-паттерн: closure получает `Transaction<Any>` и возвращает
  `(txn, Result<(), DomainError>)`, внутри — вложенный `async {}` для `?`.
- `result.take(0)` по типу `Option<Value>`/`Vec<Value>` + `serde_json::from_value`
  (доменные типы не реализуют `SurrealValue`); запись id читается как
  `record::id(id) AS id`.
- Уникальность (`code`, `login`) проверяется выборкой внутри транзакции до
  `content`-записи; при дубле — `ValidationError`.
- Live-очистка данных выполняется через `record::id(id) = '…'` (строковый
  ID `7bf0…` не является `user:uuid`-типом).

Реализация: 15 интеграционных тестов на `mem://` (round-trip, дубликаты,
idempotent schema, порядок версий, контакты/профили).

## 5в. core-infrastructure — репозиторий метаданных (Фаза 3)

`surreal_metadata_repository.rs` реализует порт `MetadataRepository` для
мета-модели (ТЗ §7, §9). Таблицы (7): `entity_types`, `entity_fields`,
`entity_states`, `entity_transitions`, `entity_forms`, `entity_actions`,
`entity_relations`.

| Аспект | Реализация |
|---|---|
| ensure_schema | 7 таблиц + UNIQUE `idx_entity_types_code_company (code, company_id)` + 4 UNIQUE `(entity_type, code)` |
| «Доска+Труба» | `with_transaction` + `assign_versions` + `write_events` (как в Фазах 2) |
| Ensure-семантика | `apply_schema`: повторный вызов с версией ≤ сохранённой → no-op без событий; новая версия → обновление по кодам ресурсов с переиспользованием record id (пользовательские добавления сохраняются) |
| Валидация переходов | `from_state`/`to_state` должны присутствовать среди новых либо уже сохранённых состояний типа иначе `ValidationError` |
| Упdates | `update_entity_type` требует существования типа (`NotFound`), повторяет тот же `apply_schema` |

**Ключевые находки (Фаза 3):**
- При перезаписи существующей записи по `(entity_type, code)` содержимое записи
  содержит собственный `id`; чтобы изменить value без конфликта, `id` в content
  подменяется на существующий record id (иначе SurrealDB: «Found … for the `id`
  field, but a specific record has been specified»).
- В команде `metadata.entity_type.update` тип переиспользуется по
  `code+company_id`: берутся существующие `id`/`created_at`, иначе событие
  уходит в «чужой» поток (проверено live, исправлено).
- `mem://`-движок и изоляция по UUID DB на тест — как в §5а.

Реализация: 6 интеграционных тестов на `mem://` (round-trip + сборка схемы,
idempotent no-op, обновление версии, валидация переходов, NotFound, idempotent schema).

## 5г. core-infrastructure — репозиторий объектов (Фаза 4)

`surreal_object_repository.rs` реализует порт `ObjectRepository` (ТЗ §7).
Таблицы (3): `objects` (Скамейка/Доска), `object_snapshots` (история версий),
`document_numbers` (атомарные счётчики номеров).

| Аспект | Реализация |
|---|---|
| ensure_schema | 3 таблицы + UNIQUE `objects(entity_type, company_id, number)` + UNIQUE `object_snapshots(object_id, version)` + UNIQUE `document_numbers(entity_type, company_id)`; поиск по `(entity_type, company_id)` |
| «Доска+Труба» | `with_transaction` + `assign_versions` + `write_events` (обобщённый результат) |
| Нумерация документов | счётчик в `document_numbers` (key `document-number-{company}-{type}`), формат `{et}-{YYYY}-{NNNN}`; присваивается в create для `kind=document`, отдельная команда `document.number.next`; откат транзакции оставляет «дыру» (допустимо v0.1) |
| OCC | `update` сверяет сохранённую версию с `obj.version` (expected); расхождение → `VersionConflict{expected, actual}` → `CONFLICT_ERROR`; успех пишет `version+1` и новый снимок |
| delete | физическое удаление только при `version == 1` (черновик без истории), иначе `ValidationError` (ТЗ §4 п.7); события `object.deleted` пишутся |
| restore_snapshot | читает снимок версии `N`, пишет объект `version+1` с данными из снимка и новый снимок (история не перезаписывается) |

> **Защита команд (Фаза 5):** все команды `CommandRegistry` (включая `object.*` Фазы 6)
> автоматически проходят через `CommandExecutionPipeline`:
> - проверка прав через `PermissionManager` (если `required_permission` задан);
> - запись в `audit_log` (`command.executed`, стадии `started`/`finished`/`denied`);
> - системный актор (`actor = None`) обходит проверку прав.

**Ключевые находки (Фаза 4):**
- `value` в SurrealQL — зарезервированное слово (модификатор `SELECT VALUE`):
  `SELECT value FROM table` падает парсером; рабочее — `SELECT *` + `.get("value")`.
- Повторный метод с возвратом значения через owned-транзакцию → `with_transaction`
  обобщена до `Result<O, _>`; методы возвращают `Object`/`String` через
  closure, а не через внешний `&mut` (нет `async move` × результат).
- Валидация полей (`Object::validate`) выполняется на командном слое (репозиторий
  не знает мета-модель): обязательность, типы, enum-options, ссылки (UUID).

Реализация: 8 интеграционных тестов на `mem://` (round-trip create/get/update +
события v1/v2, конфликт OCC, атомарная уникальная нумерация с пер-company сбросом,
снимки + restore → v3, delete-ограничение, scoping list, NotFound).

## 5д. core-infrastructure — репозиторий аудита (Фаза 4, ТЗ v3.1)

`surreal_audit_repository.rs` реализует порт `AuditRepository` (ТЗ §8.5,
Приложение №6). Коллекция `audit_log` — отдельная подсистема операционного
аудита, **не** связанная с Event Store: здесь хранятся действия пользователей
и системы (безопасность/compliance), а не бизнес-события (восстановление
состояния). `StreamType` не используется.

| Аспект | Реализация |
|---|---|
| ensure_schema | `audit_log` SCHEMALESS + 5 индексов `IF NOT EXISTS`: action+timestamp, actor.user_id+timestamp, target.entity_type+target.entity_id+timestamp, company_id+timestamp, `result`+timestamp |
| log | `with_transaction` (`events.rs`), вставка `upsert(("audit_log", id))`, id убирается из content (как `event_record`) |
| query | динамический строитель WHERE-условий с биндами (без интерполяции значений); `record::id(id) AS id`; `ORDER BY timestamp DESC`; опциональный inline-`LIMIT` |
| result-фильтр | успех хранится строкой `"success"`, неуспех — объектом `{"failure": …}`; `result_success: Some(false)` → `` `result` != $result `` |
| append-only | запись не перезаписывается в рамках операции; физическое удаление/архивация — вне порта (retention policy отложена, ТЗ §20) |

**Ключевые находки (Фаза 4):**
- `result` — зарезервированное слово SurrealQL: в `SELECT`/`WHERE`/индексе
  экранируется обратными кавычками (`` `result` ``); `type::typeof(\`result\`)`
  не парсится, поэтому проверка неуспеха — через `!= $result`.
- Индексы на вложенные поля (`actor.user_id`, `target.entity_type`) задаются
  dot-нотацией и работают в SurrealDB 3.2.

Реализация: 8 интеграционных тестов на `mem://` (round-trip, фильтры по
action/company/time/actor/result, сортировка по убыванию, limit).
Тесты 63 → 71; после Фазы 5 — 95 (§7).

## 5е. core-infrastructure/application — ModuleStore и декларативная регистрация (Фаза 9, подфаза 9b)

Подфаза 9b (раздел 9 ТЗ v3.1): «Магазин модулей» — установка/удаление WASM-модулей
и декларативная регистрация по манифесту (`ModuleManifest`, get_info) без выполнения кода плагина.

**Домен** (`core-domain/src/module.rs`):
- `ModuleRecord` — глобальный каталог `modules` (один модуль — одна запись), хранит
  полный `manifest` (источник правды для повторной регистрации при enable для других компаний),
  `state` (`installed`/`uninstalled`, удаление помечает запись, не стирает), `wasm_sha256` (16 hex —
  имя файла в модульном кэше).
- `CompanyModule` — проекция `company_modules` (пара company_id+module_code, UNIQUE).
- `PluginCallContext` — состав host-контекста вызова (module_code, company_id, actor, capabilities, settings).
- `ManifestCommand.required_permission` — право команды `plugin.{code}.{name}` (дефолт `module.execute`).

**Порты** (`core-application/src/ports.rs`): `ModuleRepository` (install/uninstall/get/list/enable/disable
для компании, list_enabled, is_enabled). `WasmHost` и `MetadataRepository` переведены на `BoxFuture`
(dyn-совместимость → `ModuleManager` на `Arc<dyn …>`).

**Хранилище** (`surreal_module_repository.rs`): таблицы `modules` + `company_modules`, индексы
`idx_modules_code` (UNIQUE) и `idx_company_modules_company_code` (UNIQUE по паре). Каждая
изменяющая операция в `with_transaction` + `assign_versions` + `write_events` (Труба + Доска).
`uninstall` также снимает включения для всех компаний (DELETE company_modules).

**ModuleManager** (`core-application/src/module_manager.rs`): `install(code, wasm, company_id)` —
load_module (host читает манифест) → запись каталога → декларативная регистрация → enable для
компании → аудит `module.installed`; `uninstall`/`enable`/`disable` + события `module.installed/
enabled/disabled/uninstalled` (StreamType::Module). Регистрация (идемпотентно): политики → upsert
(`PermissionPolicy`, entity_type — только при единственном типе, scope_type — из манифеста),
схемы → `create_entity_type` (company-scoped, `metadata.entity_type.registered`),
команды → `plugin.{code}.{name}` с handler: проверка `is_enabled_for_company` (отключённый →
`INVALID_ACTION: модуль … отключён для компании`) → `WasmHost::invoke_with_context` → `{"output": …}`,
печатные формы/скрипты → CodeRegistry::ensure.

**Команды сервера** (`module.install/uninstall/enable/disable/list/info`): требуют глобального
`module.manage` (deny-by-default). `module.install` принимает `{code, wasm_base64, company_id}`
(base64 + проверка компании). Кэш модулей — `~/.cache/2c-platform/modules` (env `MODULE_CACHE_DIR`).

**Тесты 119 → 123** (§7): 5 unit-тестов каталога + 4 интеграционных `phase9b_modules` на `mem://`
(полный цикл жизни: install/дубликат/enable для второй компании/disable → INVALID_ACTION/uninstall → снятие включений и очистка команд).

**Live-проверка** на ws://192.168.0.202:8000 (ns=main, db=2cplatform_v30): company.create →
module.install hello → plugin.hello.greet отрабатывает → module.disable → greet возвращает
`INVALID_ACTION: модуль hello отключён для компании` → module.enable для второй компании → greet успешен →
module.uninstall → `state: uninstalled`, `plugin.hello.greet` → `Unknown command`. В БД: политика
`hello.greet` (scope `{"module":"hello"}`, actions create/read), схема `greeting` для обеих компаний,
события `module.installed/enabled/disabled/uninstalled` и `metadata.entity_type.registered` (x2).

## 5ж. core-infrastructure/application — host-fn 9c (emit_event + заглушки) и reinstall (Фаза 9, подфаза 9c)

Подфаза 9c (раздел 9 ТЗ v3.1): первая **реальная** host-функция `emit_event`
(запись в Event Store) и заглушки рантайм-сервисов (скрипты, уведомления, подписи)
со строгими конвертами ошибок по Прил. №6 ТЗ. Дополнительно (требование ведущего):
**reinstall — первоклассная операция** с фиксацией «кто ставил/удалял/переустанавливал».

**`ExtismWasmHost`** (`extism_wasm_host.rs`):
- в `HostShared` добавлен порт `EventStore`; `ExtismWasmHost::new(..., events, cache_dir)`
  принимает его и передаёт host-функции `emit_event`; сигнатура обновлена у всех
  вызовов (platform-server, тесты hello_wasm/phase9b_modules);
- `emit_event(stream_id, event_type, payload_json)` — capability `events.emit`;
  нет capability → `CAPABILITY_DENIED`; не-UUID потока → `INVALID_UUID`;
  невалидный JSON → `INVALID_JSON`; пишет `Event {stream_type: Object, version: 0,
  metadata: актор вызова или system, company_id из контекста}` через `EventStore::append`
  (сбой записи → `DB_ERROR`); успех → `{"ok":true,"data":{"event_id":…}}`;
- заглушки по Прил. №6: `run_script` (`scripts`) → всегда `SCRIPT_FAILED`,
  «Rhai engine will be available in Phase 15»; `notify_user`/`users_by_role`
  (`notifications`) → `{"queued":true}` / `{"users":[]}`; `signature_required`/
  `cms_verify` (`signature`) → `{"required":false}` / `{"valid":true}`;
- `SurrealEventStore` получил `#[derive(Clone)]` (хранится в HostShared).

**Reinstall** (`surreal_module_repository.rs`, `module_manager.rs`):
- `ModuleRepository::install` на записи в состоянии `uninstalled` → перезапись
  (новый `manifest`/`wasm_sha256`) + снятие старых включений (`DELETE company_modules`);
  запись в состоянии `installed` → ValidationError (дубликат отклонён);
- `ModuleManager::install` детектит прежнюю запись через `ModuleRepository::get`:
  первичная установка / переустановка различаются событиями `module.installed` /
  **`module.reinstalled`** (payload `{"reason":"install"}` / `{"reason":"reinstall"}`)
  в потоке `StreamType::Module` + соответствующей записью `audit_log`;
- «кто…» — actor в events-metadata и audit-актор; до аутентификации (Фаза 10)
  — `ActorSnapshot::system()`, канал для реального актора готов.

**hello_plugin v1.0.0** (`examples/hello_plugin/src/lib.rs`):
- манифест: capabilities += `events.emit`, `scripts`, `notifications`, `signature`;
  команды += `events_probe`, `run_script`;
- все host-импорты объявлены в `mod host` (функции `pub`: макрос `extism_pdk::host_fn`
  генерирует обёртки с видимостью foreign-элемента; это же решает конфликт имён
  экспорта `run_script` и импорта host-fn `run_script`);
- экспорты: `events_probe` (эмитит на фиксированный поток), `run_script(source)`
  (конверт `SCRIPT_FAILED`), `stubs_probe` (все заглушки через маркеры
  `script=/notify=/users=/sigreq=/cms=` для разбора в тестах);
- фикстура `tests/fixtures/hello.wasm` пересобрана (148489 Б).

**Тесты 123 → 127** (§7): `hello_wasm.rs` +3 — `emit_event_writes_to_event_store`,
`emit_event_requires_capability` (→ `CAPABILITY_DENIED`),
`stub_workflow_and_signature_host_fns_return_spec_envelopes`; `phase9b_modules.rs` +1 —
`reinstall_after_uninstall_restores_module_and_tracks_events` (поток
`module.installed/uninstalled/reinstalled`, дубликат активного отклонён, команда после
reinstall снова исполнима).

**Live-проверка** (2026-09-09, ws://192.168.0.202:8000, ns=main, db=2cplatform_v30):
- поверх прежнего следа `hello` в `uninstalled` выполнен `module.install` →
  **переустановка**: `state=installed`, новый манифест, `module.reinstalled` (v6 в потоке
  Module), `audit_log` action `module.reinstalled` c actor system;
- `plugin.hello.events_probe` → `{"ok":true,"data":{"event_id":…}}`;
- `GET /debug/streams/object/11111111-2222-3333-4444-555555555555` → событие `hello.event.emitted`
  (payload `source=events_probe`, metadata system, company_id верный);
- `plugin.hello.run_script` → `SCRIPT_FAILED`, «Rhai engine will be available in Phase 15»;
- `module.disable` → `plugin.hello.events_probe` → `INVALID_ACTION: модуль hello отключён для компании`;
- `module.uninstall` → финальное состояние восстановлено (`state=uninstalled`).

## 5з. core-application/infrastructure — реальный `users_by_role` и `preload_company_modules` (Фаза 9, подфаза 9d)

Подфаза 9d (раздел 9 ТЗ v3.1): замена заглушек рантайм-сервисов реальной
реализацией для двух пунктов — host-fn `users_by_role` (пользователи по роли)
и включение модулей компаниям при старте (`preload_company_modules`).

**`UserRepository::list_by_role`** (`ports.rs`, `surreal_user_repository.rs`):
- сигнатура `list_by_role(&self, role_id: Uuid, company_id: Uuid)`;
  гейт по компании выполняется через роль — `User` не хранит `company_id`;
- SQL: `SELECT VALUE company_id FROM roles WHERE record::id(id) = $role_id LIMIT 1`;
  роль не найдена или принадлежит другой компании → `Ok(vec![])` (не ошибка);
- выбор пользователей: `SELECT {USER_FIELDS} FROM users WHERE role_ids CONTAINS $role_id AND status != 'archived' ORDER BY login`;
- репозиторий получил `#[derive(Clone)]` (хранится в `HostShared`); 3 модульных теста.

**`users_by_role`** (`extism_wasm_host.rs`):
- `HostShared` + поле `users: SurrealUserRepository`, конструктор получает его
  6-м параметром (`user` до `cache_dir`); все вызовы обновлены (main.rs, hello_wasm, phase9b);
- capability `notifications` (через `host_fn_dispatch`); не-UUID аргумента →
  `INVALID_UUID`, сбой хранилища → `DB_ERROR`;
- валидный, но недоступный `ctx.company_id` → `{"ok":true,"data":{"users":[]}}`;
- для каждого пользователя `login` → `get_person` (полное имя) и `list_contacts`
  (`ContactChannelType::Email`) — N+1 приемлемо для модульного окружения;
- ответ `{"users":[{id, login, full_name, email}]}` в стандартном конверте.

**`ModuleManager::preload_all`** (`module_manager.rs`, `surreal_module_repository.rs`):
- новый порт `ModuleRepository::list_enabled_companies(code)` — `SELECT company_id FROM company_modules WHERE code = $code AND enabled = true ORDER BY company_id`;
- конструктор `ModuleManager::new` получил параметр `cache_dir` (7-й) — единый
  с WASM-хостом; каталог кэша модулей;
- `preload_all() -> Result<PreloadReport, DomainError>`: все модули в состоянии
  `Installed` (сортировка по `installed_at`), для каждого — включившие компании;
  модуль с пустым списком компаний пропускается; при наличии `is_loaded` в памяти
  загрузка не дублируется (идемпотентность);
- загрузка из `{cache_dir}/{code}-{wasm_sha256}.wasm` (`tokio::fs::read`; кэш пишет
  `ExtismWasmHost::load_module` одноимённо) с последующей декларативной регистрацией
  политик/схем/команд — `register` идемпотентна, дублей команд нет;
- `PreloadReport { modules_loaded, companies_affected, errors }` (`Default`):
  сбой по отдельному модулю (например, потеря кэша) не фатален — пишется
  в `errors`, остальные модули продолжают обрабатываться;
- `main.rs`: вызов после `register_phase9_module_commands` без `?` — лог
  `warn!`/`info!`, сервер не останавливается из-за отсутствующего кэша.

**hello_plugin v1.0.0** (`examples/hello_plugin`):
- экспорт `users_probe(role_id)` — дёргает host-fn `users_by_role`, возвращает
  конверт `{"ok":true,"data":{"users":[…]}}`;
- в папке плагина добавлен локальный `.cargo/config` + `.cargo/lld-wrapper.sh`:
  глобальный `~/.cargo/config` вносит `-C link-arg=-fuse-ld=lld`, который
  rust-lld на `wasm32-unknown-unknown` не принимает; cargo конкатенирует
  `rustflags`, поэтому «обнуление» не помогает; обёртка отбрасывает `-fuse-ld=*`
  и вызывает настоящий `rust-lld` из sysroot. Сборку запускать из каталога
  плагина (`cd examples/hello_plugin && cargo build …`) — cargo читает
  `.cargo/config` от текущего каталога;
- фикстура `tests/fixtures/hello.wasm` пересобрана (149310 Б).

**Тесты 127 → 138** (§7): `hello_wasm.rs` +4 —
`users_by_role_9d_returns_users_with_person_and_email`,
`users_by_role_9d_denies_without_notifications_capability` (→ `CAPABILITY_DENIED`),
`users_by_role_9d_missing_role_returns_empty_list`,
`users_by_role_9d_foreign_company_role_returns_empty_list`;
`phase9d_preload.rs` (новый файл) +3 — загрузка и регистрация модуля для двух
включивших его компаний, идемпотентность повторного `preload_all`, потеря кэша
без падения (`errors` непуст) с восстановлением и исполнением команды модуля.

## 5и. core-application/infrastructure — транзакционная оркестрация `tx_exec` (Фаза 9, §9 ТЗ)

Заключительная подфаза 9: WASM-модули получают API атомарных пачек операций
над объектами с `$ref`-связыванием и идемпотентностью по бизнес-ключу.

**`ObjectRepository::update_batch`** (`ports.rs`, `surreal_object_repository.rs`):
- `fn update_batch(&self, ops: &[(Object, Vec<Event>)]) -> Result<Vec<Object>, DomainError>`
  — атомарная пачка: внутри одного `with_transaction` для каждой записи
  `load_object` → `current_version_checked` (OCC по `obj.version`) →
  `write_object` + `write_snapshot`; в конце единый `assign_versions` +
  `write_events` для всех событий пачки;
- сбой любой записи (включая `VersionConflict`) отменяет всю транзакцию;
- весь трейт `ObjectRepository` переведён с RPITIT (`impl Future`) на
  `BoxFuture<'_, _>` — требование trait-object `Arc<dyn ObjectRepository>`
  для оркестратора (паттерн остальных репозиториев);
- модульные тесты: `update_batch_is_atomic_and_rolls_back_whole_batch`
  (stale-запись → конфликт, первая запись откатывается),
  `update_batch_applies_all_and_writes_events` (обе записи v2, события в потоке).

**`TransactionOrchestrator`** (`core-application/src/transaction_orchestrator.rs`):
- состояние: `RwLock<HashMap<Uuid, ActiveTransaction>>`; `ActiveTransaction`
  хранит `business_key`, `company_id`, `actor`, `operations: Vec<PendingOperation>`
  (у каждой `result: Option<Value>`), `status`, `created_at`;
- `begin(business_key, company_id, actor) -> (Uuid, usize)`: при непустом ключе
  и существующей активной пачке (тот же ключ+компания+исполнитель) возвращает
  прежний handle и число операций (идемпотентность повторной попытки); пустой
  ключ — всегда новая пачка; `company_id`/`actor` фиксируются в момент begin;
- `add_op(handle, op_type, params) -> Uuid`: мгновенная валидация
  `op_type ∈ {object.post, object.cancel, test.noop}` (иначе `ValidationError`);
- `commit(handle)`: выполнение всех операций (последовательно, внутри —
  `resolve_refs` для каждой), сбор `(Object, Vec<Event>)` в батч, затем один
  `object_repo.update_batch(&batch)`; успех → пачка удаляется из карты;
  ошибка (включая `VersionConflict`) → `status` снова `Active`, пачка
  возвращается в карту для повтора;
  - `object.post`/`object.cancel`: обязательный `id` (UUID) и опциональный
    `expected_version`; объект загружается, проверяется принадлежность компании
    транзакции (иначе `ValidationError`), меняется канонический `state` на
    `posted`/`cancelled`, формируется событие `object.posted`/`object.cancelled`;
  - `test.noop`: эхо параметров — `{"ok":true,"params":<переданный JSON>,"noop_id":<op_id>}`;
- `resolve_refs(value, ops, depth)`: узел `{"$ref": "<op_id>.path.to.field"}`
  заменяется значением из результата операции по dot-пути (с рекурсивным
  проходом); неизвестный op/путь → `ValidationError`; лимит глубины 10;
- фоновый GC: `tokio::time::interval(60s)` (handle из `Handle::try_current`,
  вне runtime пропускается), `prune_expired` отбрасывает пачки старше TTL 5 мин;
- `create` API-расширение: `pub fn new(object_repo: Arc<dyn ObjectRepository>) -> Arc<Self>`
  (экспорт из `core_application::TransactionOrchestrator`);
- 8 unit-тестов (MemObjectRepo-заглушка с OCC): успешный батч, идемпотентность,
  неизвестный op_type, эхо noop для `$ref`, битая `$ref` (handle активен),
  вложенный путь и лимит глубины, чужая компания, конфликт версий (handle активен).

**host-fn `tx_exec`** (`extism_wasm_host.rs`, capability `transactions`, namespace `ExtismHost`):
- `tx_begin(business_key: String)` → `{"handle": uuid, "operations_count": n}`;
- `tx_add_op(handle, op_type, params_json)` → `{"op_id": uuid}` (не-UUID → `INVALID_UUID`,
  невалидный JSON → `INVALID_JSON`, пустой `op_type` → `INVALID_ACTION`);
- `tx_commit(handle)` → `{"committed": true}`;
- маппинг ошибок через `host_err_code` + `DomainError::code()` (Приложение №6 ТЗ):
  `NotFound → NOT_FOUND`, `VersionConflict → CONFLICT_ERROR`,
  `ValidationError → INVALID_ACTION`, `PermissionDenied → CAPABILITY_DENIED`,
  `Storage → DB_ERROR`;
- `HostShared` получил поле `transactions: Arc<TransactionOrchestrator>`,
  конструктор `ExtismWasmHost::new(db, objects, metadata, events, users, transactions, cache_dir)`
  (7-й параметр); в `main.rs` оркестратор создаётся перед хостом как
  `TransactionOrchestrator::new(objects.clone())`.

**hello_plugin** (`examples/hello_plugin`, фикстура 164029 Б):
- манифест: capability `transactions` + команда `tx_probe`;
- foreign-fn `tx_begin`/`tx_add_op`/`tx_commit` (String → String), namespace `ExtismHost`;
- экспорты `tx_probe` (begin→post→commit), `tx_ref_probe` (noop с `target_id` →
  object.post через `$ref` на результат noop), `tx_idem_probe` (два begin с тем же
  ключом, между ними noop) — каждый возвращает JSON из сырых конвертов.

**Тесты 138 → 153** (§7): `hello_wasm.rs` +5 — успешный коммит (объект `posted`,
v2), `$ref`-связывание из результата noop, идемпотентность `begin` (тот же handle,
`operations_count` растёт), отказ без capability (`CAPABILITY_DENIED`), конфликт
версий при коммите (`CONFLICT_ERROR`, недо-транзакция не изменяет объект).

## 6. platform-server

Бинарник на Axum 0.8:
- `GET /health` → 200 OK;
- `POST /rpc` — конверт `RpcMessage` (Command/Query/EventBatch) либо legacy-форма `{ "name": "…", "params": {…} }` (Фаза 10a): резолв `core`→action / `plugin.{module}.{action}`, `Response`/`Error` (коды + HTTP 404/409/422/403/500), идемпотентность Command по `(actor_user_id, request_id)`, `EventBatch` (module=`core`) → append в Трубу; актор из `Authorization: Bearer <JWT>` (Фаза 10b), без токена — `ActorSnapshot::anonymous()`, `user.login`/`user.logout` — unrestricted-команды;
- `POST /debug/events` — приём `Vec<Event>` → `append` (отладка);
- `POST /debug/command` — `{ "name": "…", "params": {…} }` → `registry.execute` (39 команд: 31 Фазы 2-6/8 + `module.install`/`module.uninstall`/`module.enable`/`module.disable`/`module.list`/`module.info`/`module.navigation` + `system.bootstrap`);
- `POST /debug/push` (Фаза 10c) — `{ "module": "…", "event_type": "…", "payload": {…}? }` → публикация `ServerPush` в `PushHub` (получат подключённые WS-клиенты);
- `GET /ws` (Фаза 10c) — WebSocket-транспорт `RpcMessage`: актор из `?token=<JWT>` (без токена — аноним), входящие Command/Query/EventBatch через общий `process()`, ответы/`ServerPush` — текстовыми JSON-фреймами;
- `GET /debug/streams/{kind}/{sid}` — `read_stream` по типу (10 видов StreamType);
- подключение к SurrealDB при старте (env `SURREAL_*`, dotenvy), `ensure_schema`
  всех коллекций (events + 8 таблиц Фаз 2 + 7 таблиц метаданных + 3 таблицы объектов + `audit_log`), регистрация команд;
- `ModuleManager::preload_all` при старте (подфаза 9d): загрузка установленных
  модулей из кэша и идемпотентная повторная регистрация; сбой кэша — `warn!`,
  сервер продолжает запуск;
- graceful shutdown по сигналу (Ctrl+C / SIGTERM).

Команды `apps/platform-server/src/commands.rs`:

| Команда | Событие(-ия) | Примечание |
|---|---|---|
| `company.create` | `company.created` | UNIQUE `code` |
| `company.update` | `company.updated` | неявный merge; v2 в потоке |
| `company.get` / `company.list` | — | чтение «Доски» |
| `user.create` | `user.created` + `person.created` | `person.id == user.id` |
| `user.update` | `user.updated` | статус/timezone/etc. |
| `user.get` / `user.list` | — | чтение «Доски» |
| `user.contact.add` | `user_contact.created` | channel/purposes из перечислений |
| `user.profile.add` | `user_profile.created` | привязка к компании/роли |
| `role.create` | `role.created` | UNIQUE `code` |
| `role.get` / `role.list` | — | чтение «Доски» |
| `metadata.entity_type.create` | `metadata.entity_type.created` | ensure по `metadata_version`; повторный вызов — no-op |
| `metadata.entity_type.update` | `metadata.entity_type.updated` | reuse `id`/`created_at` по `code+company_id` |
| `metadata.entity_type.get` / `get_by_code` / `list` | — | чтение «Доски» |
| `metadata.schema.get` | — | полная схема типа (fields/states/transitions/forms/actions/relations) |
| `object.create` | `object.created` | валидация по схеме; номер `{et}-{YYYY}-{NNNN}` при `kind=document` |
| `object.get` / `object.list` | — | чтение «Доски» (list scoping по entity_type+company) |
| `object.update` | `object.updated` | OCC: `expected_version` обязателен, иначе `CONFLICT_ERROR` |
| `object.delete` | `object.deleted` | только черновик без истории (`version==1`) |
| `object.snapshot.list` | — | история версий объекта |
| `object.snapshot.restore` | `object.restored` | восстановление из версии N → новая версия |
| `document.number.next` | — | «за наряд» без записи; атомарно инкрементирует счётчик |
| `audit.log` | — | запись в `audit_log`; актор по умолчанию `ActorSnapshot::system()`, результат `Success` |
| `audit.query` | — | выборка по фильтру (action/actor/company/time/result), `ORDER BY timestamp DESC`, limit |
| `role.seed` | (нет) | сид 4 системных ролей и 6 политик для компании; ensure-семантика; дополняет существующие роли (Фаза 5, `bfa782e`) |
| `system.migrate_permissions` | (нет) | идемпотентная миграция компаний, созданных до Фазы 5: сид ВСЕХ компаний, существующие роли дополняются политиками, аудит `{companies_total, seeded, policies_added}` (Фазы 5, `bfa782e`) |
| `module.navigation` | — | навигация установленных модулей (доработка перед 11б): read-срез `{code, display_name, version, navigation[]}` только для модулей с доступными актору командами; requires `module.read` (политика `platform.modules`, staff/guest) |
| `system.bootstrap` | — | однократная инициализация платформы: компания + суперадмин (Argon2id) + сид + привязка роли/профиля + аудит; доступна только системному актору (`requires("system.bootstrap")`, через `/debug/command`) |

Все события Фаз 2-6 записываются с системным актором `ActorSnapshot::system()`
(`user_id`/`company_id`/`position` = None, `login` = «system», `full_name` = «Система»).

## 7. Команды и верификация

```bash
cargo build --workspace
cargo test --workspace            # 251 тест (42 core-domain + 21 core-application + 76 infra-unit + 19 hello_wasm + 10 phase5_rbac + 5 phase9b_modules + 3 phase9d_preload + 5 phase13_scripts + 8 core-api unit + 10 phase10a_rpc + 8 phase10b_auth_rpc + 3 phase10c_ws + 12 phase14_accounting + 8 phase11_navigation + 6 phase_bootstrap)
cargo clippy --workspace --all-targets   # 0 предупреждений (таймаут >= 600s)
cargo tree -p core-domain -e normal      # без surrealdb/axum/extism
```

Результат последней проверки (Доработка перед 11б + system.bootstrap, 2026-09-14): build ✅, test 251/251 ✅, clippy ✅, tree ✅.

**Живая проверка Фазы 14** (2026-09-13, против `ws://192.168.0.202:8000`, ns=main,
db=2cplatform_v30):
- Полный цикл `/rpc` + Bearer JWT: `user.login` → `module.install` (системный актор,
  `/debug/command`) → `account.create` (10.01 asset, 90.01 revenue) → `period.open`
  (2026-09) → `entry.post` (Дт 10.01 15000 / Кт 90.01 15000) → `balance.trial`
  (totals debit=credit=15000, 2 строки) → `entry.list`. Ответы плагина — конверт
  `{"output":"<строка-JSON>"}`.
- Роутинг `/rpc` для плагинных команд: `{"module":"accounting","action":"<action>",...}`
  (не `module:"plugin"`); повторный запрос с тем же `id` возвращает закэшированный
  ответ (идемпотентность Command).
- **Факт RBAC, всплывший при тестировании:** пользователь с ролью `admin`
  (`platform.full`, actions `["*"]`) НЕ может выполнять permission-gated команды
  (в т.ч. плагинные `plugin.accounting.*`), пока у него нет привязки к компании:
  JWT `company_id = null` → `_authorize` (`command_registry.rs:226`) отсекает по
  компании ДО проверки роли/политики → `PERMISSION_ERROR`. Привязка добавляется
  командой `user.profile.add {user_id, company_id, position}`; после повторного
  `user.login` `company_id` попадает в токен и `platform.full` покрывает module-скоуп.
  `user.create` привязку НЕ создаёт (даже при переданном `company_id`).
- `module.install` в live выполнялся системным актором через `/debug/command`
  (актор не задан → разрешено), а не пользователем через `/rpc`; команда требует
  параметр `company_id` (UUID существующей компании).

**Живая проверка system.bootstrap и доработки перед 11б** (плановая; против
`ws://192.168.0.202:8000`, ns=main, db=2cplatform_v30; сценарий):
- `system.bootstrap {company_code, company_name, admin_login, admin_password,
  admin_last_name, admin_first_name}` через `/debug/command` (системный актор) →
  ответ `{company_id, company_code, admin_user_id, admin_login, roles_seeded: 4,
  policies_seeded: 6}`; повторный вызов → `VALIDATION_ERROR` «Платформа уже
  инициализирована. Для добавления компаний используйте company.create».
- `user.login` созданного админа → `AuthToken` (JWT), `user.profile.add` уже
  создан бутстрапом (primary) → `company_id` в токене есть с первого логина.
- `module.install accounting` (пересобранная фикстура с navigation) →
  `module.navigation` от админа → `[{code: accounting, display_name: «Управленческий
  учёт», version, navigation: [{code: accounts, label: «План счетов»,
  entity_type: account}, {code: periods, label: «Учётные периоды»,
  entity_type: accounting_period}, {code: entries, label: «Журнал проводок»,
  entity_type: ledger_entry}]}]`; срез без `wasm_sha256`/манифеста/capabilities.
- `module.disable` → повторный `module.navigation` → модуль исчез из ответа.
- Аноним → `PERMISSION_ERROR`; `staff`/`guest` без granted-политики на команды
  модуля видят пустой список (deny-by-default) до добавления политики с
  действием, равным `required_permission`.
- Тестовые данные после проверки очищены.

**Живая проверка Расширения 1 (фазы 15pre-2/15pre-3, SDUI ядровых сущностей
+ редактор метаданных)** (2026-09-16, против `ws://192.168.0.202:8000`,
ns=main, db=2cplatform_v30; клиент — `2c_client`):
- **Создание компании через SDUI-каталог:** `user.login` админа (JWT с
  `company_id`) → `module.navigation` → synthetic-модуль `platform`
  («Компании»/«Пользователи»/«Роли») → `/catalog/company` (DataTable из
  системной схемы `company`, `is_system=true`, `company_id=""`) → FAB →
  ObjectFormScreen (поля `code`/`name` из схемы) → `object.create
  {entity_type:"company", kind, data}` → сервер делегирует в `company.create`,
  в Трубу пишется `company.created`, объект появляется в каталоге и в
  `object.get`; списки `company` фильтруются по компании актора через роли.
- **Редактор метаданных:** `/metadata/editor` → схема типа из
  `metadata.schema.get`, секции Поля/Состояния/Переходы, сохранение =
  бамп `metadata_version` + `metadata.import` (пара `export`→`import` и
  orphan-синхронизация `delete_orphans` на живой базе).
- **Факт wire-контракта, подтверждённый live:** для ядровых типов клиент
  шлёт обычный `object.*`-конверт (поля Object-формы со schema data_type),
  серверная делегация в `company.*`/`user.*`/`role.*` прозрачна для клиента.

**Живая проверка Фазы 15.4 (авто-хук привязанных скриптов)** (2026-09-17, против
`ws://192.168.0.202:8000`, ns=main, db=2cplatform_v30; сервер перезапущен на
новом бинарнике — live): 
- Сценарий: `metadata.entity_type.create` (тип `note`, поля title/qty/price,
  состояние draft) → `script.create` формула
  `#{ total: ctx.object.data.qty * ctx.object.data.price }` (entity_type=note,
  is_active=true) + `script.create` валидатор
  `ctx.object.computed.total >= 0` (entity_type=note) → `object.create`.
- **Формула в live:** `object.create {qty:3, price:150}` → ответ
  `computed: {total: 450}` ✓ (по тестовым прототипам «computed пуст» — факт,
  связанный со старым бинарником до 15.4).
- **Валидатор в live:** `object.create {qty:-3, price:150}` → отклонён:
  `Невалидные данные: валидатор 'nonneg_total' отклонил объект типа 'note'` ✓.
- **Update в live:** `object.update` того же объекта (+`expected_version:1`,
  qty:5/price:100) → `computed: {total: 500}`, `version:2` — формула
  пересчитывается при обновлении ✓.
- Факт: для live-проверки авто-хука потребовался перезапуск `platform-server`
  на актуальном бинарнике (старый не содержал script_hooks в object.create/update).
- Тестовые объекты/схема `note` оставлены за системным актором (не мешают).

**Живая проверка Фазы 2** (2026-09-05, против `ws://192.168.31.31:8000`, ns=main,
db=2cplatform_v30):
- Сервер подключился, `ensure_schema` создала 8 таблиц + 4 индекса событий;
- `company.create` → `company.get/list/update` (событие `company.updated` как v2);
- `user.create` (создаёт `user.created` + `person.created`) → `user.contact.add`,
  `user.profile.add`, `role.create/get/list`;
- Дубликаты `company.code`, `user.login`, `role.code` → ValidationError (сообщение на русском);
- невалидный UUID / неизвестный тип потока → HTTP 400;
- `GET /debug/streams/{kind}/{id}` отдаёт события в порядке версий с системным актором.
- Тестовые данные очищены (0 записей во всех таблицах), схема сохранена.

**Живая проверка Фазы 3** (2026-09-06, против `ws://192.168.0.202:8000`, ns=main,
db=2cplatform_v30):
- Сервер поднялся, зарегистрировано 18 команд (12 Фазы 2 + 6 метаданных);
- `metadata.entity_type.create` (invoice: 2 поля, 2 состояния, переход, форма,
  действие, relation) → `schema.get` собрал полную схему; `get_by_code`/`list` — ок;
- повторный `create` той же версии → no-op: в Трубе 1 событие, дублей нет;
- `metadata.entity_type.update` (metadata_version 2) → версия 2, поля/состояния
  обновлены по кодам, пользовательские ресурсы сохранены;
- невалидный переход (`done` → `open` без состояния `done`) → ValidationError, HTTP 400;
- исправлен дефект: обновление тип по кодом (reuse `id`/`created_at`) — события
  `created`+`updated` в одном потоке с последовательными версиями;
- тестовые данные удалены (0 записей в 7 таблицах метаданных и в `events`).

**Живая проверка Фазы 4** (2026-09-06, против `ws://192.168.0.202:8000`, ns=main,
db=2cplatform_v30):
- Сервер поднялся, зарегистрировано 27 команд (12 Фазы 2 + 6 метаданных + 8 объектов + `document.number.next`);
- `metadata.entity_type.create` (invoice: money/reference/enum поля, draft→posted) → `object.create`
  присвоил номер `invoice-2026-0001`, `version=1`, `kind=document`;
- `object.update` expected=1 → `version=2` (сумма 2500); stale-автор с expected=1 →
  `Конфликт версий: ожидалась 1, актуальная 2` (HTTP 400);
- `object.snapshot.list` → 2 снимка (v1/v2); `object.snapshot.restore` v1 → `version=3`
  (сумма вернулась к 1000, история сохранена);
- `object.delete` объекта с историей → `Удаление объекта с историей запрещено`;
- `document.number.next` → `invoice-2026-0002` (атомарный инкремент счётчика);
- `GET /debug/streams/object/{id}` → события `object.created/updated/restored` версиями 1/2/3;
- тестовые данные очищены (0 в objects/object_snapshots/document_numbers/events/метаданных invoice; схемы сохранены).

**Живая проверка аудита (Фаза 4, ТЗ v3.1)** (2026-09-07, против
`ws://192.168.0.202:8000`, ns=main, db=2cplatform_v30):
- Сервер поднялся, зарегистрировано 29 команд (+ `audit.log`, `audit.query`);
  `ensure_schema` создала `audit_log` и 5 индексов.
- `audit.log {action: "test.action"}` → запись с системным актором
  («Система»/«system»), `result: "success"`, `timestamp` RFC3339;
- `audit.query {}` → вернул запись целиком;
- `audit.log` с `company_id` → `audit.query {company_id}` вернул только её;
- `audit.log` с `result: {"failure": {"reason": "test"}}` → `audit.query {result_success: false}`
  вернул только упавшую запись (функция `type::typeof(\`result\`)` не парсится —
  фильтр через `!= "success"`);
- прямой SQL `SELECT count() … GROUP ALL` → 3 записи; содержимое `result` различает
  строку `"success"` и объект `{"failure": …}`;
- тестовые данные очищены (`DELETE FROM audit_log` → 0), схема сохранена.

**Верификация WASM-хоста (Фаза 9, подфаза 8a)** (интеграционные тесты, `mem://`,
2026-09-08, коммит `11721c6`):
- `examples/hello_plugin` (get_info/greet/kv_probe) собран в
  `wasm32-unknown-unknown`, фикстура `tests/fixtures/hello.wasm`;
- 4 теста `hello_wasm.rs` зелёные: валидация манифеста v2 и сверка `code`,
  вызов `greet` с host-fn `whoami`/`log_message`, KV round-trip через `kv_probe`,
  выгрузка/повторная выгрузка и вызов после выгрузки;
- host-fn `log_message` — void (без результата), остальные возвращают конверт;
- KV через SurrealDB `module_kv`, атомарный `put_if_absent` (`with_transaction`);
- live-проверка вынесена в подфазы 9b–9c.

**Чек-лист live-проверки транзакций (Фаза 9, подфаза 9e; ручной прогон против
`ws://192.168.0.202:8000`, ns=main, db=2cplatform_v30):**

```bash
BASE=:8080/debug/command

# 1. компания и установка модуля hello
curl -s -X POST $BASE -H 'Content-Type: application/json' \
  -d '{"name":"company.create","params":{"code":"txdemo","name":"TX Demo"}}'
curl -s -X POST $BASE -H 'Content-Type: application/json' \
  -d '{"name":"module.install","params":{"code":"hello","cache_dir":"..."}}'
# 2. схема документа (draft/posted/cancelled) + создание объекта draft v1
curl -s -X POST $BASE -H 'Content-Type: application/json' \
  -d '{"name":"metadata.entity_type.create","params":{...}}'
curl -s -X POST $BASE -H 'Content-Type: application/json' \
  -d '{"name":"object.create","params":{"entity_type":"document","data":{...}}}'
# 3. транзакционная проба: begin → object.post → commit
curl -s -X POST $BASE -H 'Content-Type: application/json' \
  -d '{"name":"plugin.hello.tx_probe","params":{"object_id":"<id>","expected_version":1}}'
#    ожидание: begin {handle,operations_count:0}, commit {committed:true}, объект posted v2
# 4. отключение модуля → повтор tx_probe должен вернуть INVALID_ACTION
curl -s -X POST $BASE -H 'Content-Type: application/json' \
  -d '{"name":"module.disable","params":{"company":"txdemo","code":"hello"}}'
```

Ожидаемые коды конверта: `INVALID_ACTION` (неизвестный op_type / чужая компания),
`NOT_FOUND` (нет объекта), `CONFLICT_ERROR` (stale `expected_version`),
`CAPABILITY_DENIED` (контекст без права `transactions`), `INVALID_UUID`,
`INVALID_JSON`.

## 8. Известные ограничения

- `core-api` — пустой каркас (doc-комментарии). Наполнение — фаза 10 (транспорт).
- WASM-хостинг (Extism) реализован в подфазе 8a (`ExtismWasmHost`, манифест v2, host-fn
  8a, `ModuleKv`). Остались host-fn 8b–8d, декларативная регистрация, `ModuleStore`,
  лимиты/конвейер и live-проверка (подфазы 9b–9c). `examples/hello_plugin` вне workspace
  (отдельная сборка `wasm32-unknown-unknown`, `workspace.exclude`).
- `user_certificates` — таблица и модель есть, команды добавления сертификата нет (YAGNI).
- `surreal-tui` удалён (коммит `79551d0`): автономная утилита, не член workspace.
- Метаданные Фазы 3 покрывают декларативную часть: `entity_actions` хранит только
  описание (handler), исполнение появится с WASM (Фаза 9).