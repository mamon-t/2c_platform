# 2C Platform — Технический отчёт о состоянии фронтенда (Flutter-клиент)

> **Рабочий документ.** Локальный, не версионируется в git (в `.gitignore`).
> Ведётся параллельно `doc/technical_report.md` (бэкенд), но по задачам клиента.
> Обновляется по результатам каждой подфазы работ над `2c_client/`.

- **Дата:** 2026-09-17
- **Репозиторий:** локальный git в `/home/mikhail/develop/2C`
- **Проект:** `2c_client/` (Flutter 3.x, desktop-first: Linux/Windows)

---

## 1. Статус

Фаза 11a завершена (коммит `c367e26`): каркас Flutter-клиента собран,
верифицирован (build/tests/analyze) и проверен против живого сервера
(login → JWT 8ч, PERMISSION_ERROR, WS + `/debug/push` → ServerPush).
Фаза 11b (SDUI-рендеринг) завершена (коммит `302e224`): каталоги и формы
строятся из метаданных платформы — 92 теста, analyze чист, build linux OK.
**Расширение 1 (коммиты `2a837d6`, `5caf46f`):** SDUI ядровых сущностей
(компании/пользователи/роли рендерятся как обычные каталоги/формы через
synthetic-модуль `platform`, роуты `/catalog/company` и др., список
фильтруется по компании актора) и редактор метаданных
(`metadata_editor_screen`, `/metadata/editor/:entityType?`, секции
Поля/Состояния/Переходы, экспорт/импорт JSON через `metadata.export`/
`metadata.import`, бамп `metadata_version`). Live-верификация 15pre — §9.
**Фаза 15.2 (коммит `772bd07`):** каталог скриптов — `ScriptListScreen`
`/scripts` (DataTable + метки типов + статусы, FAB, RefreshIndicator),
`ScriptEditorScreen` `/scripts/new`+`/scripts/:code/edit` (форма, «Проверить»=
`script.validate` с панелью ошибок и координатами, «Прогнать»=`script.test`
с временем выполнения), `ScriptService` + `scriptsProvider`, пункт «Скрипты»
в home-навигации за `script.manage`; 159 тестов, analyze 0.
**Фаза 15.3 (коммит `e7e6c68`):** Rhai-редактор — подсветка синтаксиса
(`core/rhai_grammar.dart`, Mode на базе rust.dart: ключевые слова, встроенные
функции, строки/raw-строки, числа, комментарии, `fn`, `const`; поверх
`flutter_highlight` фоном + прозрачный `TextField` с цветным курсором,
тема из colorScheme) и клиентский пре-чек «;» (`core/rhai_precheck.dart`,
консервативный: блоки/заголовки `if`/`while`/`for`/`fn`, продолжения
выражений, круглые скобки, комментарии, последний оператор — не требуют `;`);
местные конфигурации подсветки/пре-чека через Switch «strict „;\"» —
при строгом режиме сохранение блокируется SnackBar-сообщением с координатой,
панель «Клиентский пре-чек:» с проблемами; +11 тестов (precheck 10, editor 3)
→ 172 тестов, analyze 0.
Серверная инфраструктура готова (Фаза 10, доработка перед 11б:
`module.navigation`/`platform.modules`, `system.bootstrap`):
`POST /rpc` (Command/Query/EventBatch → `RpcMessage`), `GET /ws?token=<JWT>`
(ServerPush через PushHub), `user.login`/`user.logout` (JWT HS256, Argon2id),
идемпотентность Command `(actor_user_id, request_id)` TTL 5 мин.

**Согласовано с ведущим (внешняя сверка контрактов):**
- Модель `RpcMessage` — 6 вариантов (`command`/`query`/`event_batch`/`response`/
  `error`/`server_push`), тег `type`, значения `snake_case` (`rpc_message.rs`).
- Серверных кодов ошибок ровно 5: `NOT_FOUND_ERROR`, `CONFLICT_ERROR`,
  `VALIDATION_ERROR`, `PERMISSION_ERROR`, `STORAGE_ERROR`. `AUTH_REQUIRED` —
  клиентская концепция (трактовка `PERMISSION_ERROR` на защищённом экране).
- Refresh-токенов на сервере нет; с Фазы 11a access TTL JWT = **8 часов**
  (изменение сервера, коммит `63b290c`). При истечении — повторный вход.
- HTTP-клиент — `http` (не dio); refresh-механизм — в Фазе 12 (оффлайн).

---

## 2. Фазы клиента

| ID | Фаза | Статус | Комментарий | Коммит |
|---|---|---|---|---|
| 11a | Каркас Flutter-клиента | ✅ Done | desktop (Linux/Windows), RpcMessage (6), RpcClient, WsClient+reconnect, JWT-логин, go_router+Riverpod, тёмная тема, экраны login/home/settings, маппинг ошибок, тесты (34 passed, analyze чистый, build linux OK) | `c367e26` |
| 11b | SDUI-рендеринг из метаданных | ✅ Done | модели entity_schema/object/navigation_item, MetadataService/ObjectService, sdui_providers, WidgetRegistry + 12 тип-виджетов, CatalogScreen (DataTable), ObjectFormScreen (create/view/edit, OCC, конфликт→диалог), роуты каталога/формы, drawer из module.navigation, 58 новых тестов (92 всего), analyze 0, build linux OK | `302e224` |
| 15pre-2 | SDUI ядровых сущностей | ✅ Done | компании/пользователи/роли рендерятся без изменения wire-контракта: synthetic-модуль `platform` в `module.navigation` («Компании»/«Пользователи»/«Роли»), каталоги/формы через существующие Catalog/ObjectForm (системные схемы `company`/`user`/`role` из глобального `company_id=""`), список фильтруется по компании актора; тесты +9 (home_screen 5, core_entity_catalog 4) → 121; analyze 0 | `2a837d6` |
| 15pre-3 | Редактор метаданных + экспорт/импорт | ✅ Done | модели `toJson/copyWith` (+ id/metadataVersion), `MetadataService.createEntityType`/`exportMetadata`/`importMetadata` (со сбросом кэша), SDUI-редактор `metadata_editor_screen` (выбор типа, секции Поля/Состояния/Переходы с диалогами, каскадное удаление переходов, guard последнего состояния, бамп `metadata_version` при сохранении, экспорт/импорт JSON, «Новый тип»), пункт «Метаданные» + роут `/metadata/editor/:entityType?`; тесты +10 (`metadata_editor_screen_test`) → 131; analyze 0, build linux OK | `5caf46f` |
| 15.2 | Каталог скриптов | ✅ Done | модель `ScriptItem`, `ScriptService` (list/get/create/update/delete/validate/testRun, контракт `{valid,errors:[{line,column,message}]}`), `scriptsProvider`; `ScriptListScreen` `/scripts` (DataTable Код/Название/Тип/Статус + метки типов, FAB «Создать», RefreshIndicator); `ScriptEditorScreen` `/scripts/new`+`/scripts/:code/edit` (форма код/название/тип/тип сущности/активен/исходник monospace, кнопки «Проверить»=validate с панелью координат и «Прогнать»=test со временем, «Сохранено»); пункт «Скрипты» в home за `script.manage` (code `scripts`, entity_type null) → `/scripts`; тесты +27 (model 4, service 11, list 5, editor 8) + home-кейс «Скрипты» → 159; analyze 0 | `772bd07` |
| 15.3 | Rhai-редактор: подсветка + пре-чек | ✅ Done | подсветка `core/rhai_grammar.dart` (Mode из rust.dart, `flutter_highlight` фоном + прозрачный `TextField`, тема из colorScheme, `registerRhaiHighlight`), пре-чек `core/rhai_precheck.dart` (консервативный «не завершён „;\""; блоки/заголовки/скобки/комментарии/последний оператор — ок), Switch «strict „;\"" (блокирует сохранение с координатой в SnackBar), панель «Клиентский пре-чек:»; +11 тестов (precheck 10, editor 3) → 172; analyze 0 | `e7e6c68` |

---

## 3. Структура проекта

```text
2c_client/
├── pubspec.yaml
├── lib/
│   ├── main.dart                    # входная точка, инициализация
│   ├── app.dart                     # MaterialApp, тема, роутер
│   ├── core/
│   │   ├── config.dart              # адрес сервера, настройки
│   │   ├── theme.dart               # тёмная тема
│   │   └── router.dart              # go_router
│   ├── models/
│   │   ├── rpc_message.dart         # RpcMessage конверт (ТЗ §10)
│   │   ├── auth_token.dart          # AuthToken + JWT claims
│   │   ├── server_error.dart        # маппинг кодов ошибок
│   │   ├── event.dart               # Event / ActorSnapshot (для EventBatch)
│   │   ├── entity_schema.dart       # meta-модель типа (11b): схема/поля/состояния
│   │   ├── object.dart              # универсальный объект (data/computed/version)
│   │   ├── navigation_item.dart     # module.navigation (11b)
│   │   └── script.dart              # 15.2: ScriptItem (код/тип/строки/статус)
│   ├── core/
│   │   ├── rhai_grammar.dart        # 15.3: Mode Rhai для подсветки (flutter_highlight)
│   │   └── rhai_precheck.dart       # 15.3: RhaiIssue + rhaiPrecheck («;»)
│   ├── services/
│   │   ├── rpc_client.dart          # HTTP POST /rpc (UUID id, таймаут 30 с)
│   │   ├── ws_client.dart           # WebSocket GET /ws + reconnect (backoff 1→30 с)
│   │   ├── auth_service.dart        # login/logout/tryRestore/refresh
│   │   ├── metadata_service.dart    # entity_type.list / schema.get (кэш)
│   │   ├── object_service.dart      # object.list/get/create/update
│   │   └── script_service.dart      # 15.2: script.* + validate/testRun
│   ├── providers/
│   │   ├── app_providers.dart       # appConfig, rpc, ws, auth (AuthController),
│   │   │                            # routerRefresh (ValueNotifier → реактивный redirect)
│   │   └── sdui_providers.dart      # 11b: companyId/schemas/schema/objects/navigation
│   │                                # 15.2: + scripts
│   ├── sdui/
│   │   ├── widget_registry.dart     # 11b: WidgetRegistry (тип-виджет по data_type)
│   │   ├── value_format.dart        # 11b: displayValue для таблиц
│   │   └── widgets/                 # 11b: тип-виджеты (TextInputField-база),
│   │                                # строки/числа/money/даты/boolean/enum/
│   │                                # reference/array+table/json/read-only
│   └── screens/
│       ├── login_screen.dart        # экран логина
│       ├── home_screen.dart         # drawer + тело из module.navigation (11b)
│       ├── settings_screen.dart     # настройки (адрес сервера)
│       ├── catalog_screen.dart      # 11b: DataTable объектов типа
│       ├── object_form_screen.dart  # 11b: create/view/edit с OCC
│       ├── metadata_editor_screen.dart  # 15pre-3: редактор метаданных
│       ├── script_list_screen.dart      # 15.2: каталог скриптов /scripts
│       ├── script_editor_screen.dart    # 15.2/15.3: редактор скрипта /scripts/new|:code/edit
│       │                                # 15.3: подсветка HighlightView + «;»-пре-чек
└── test/
    ├── models/…                     # round-trip сериализации (6 вариантов + ошибка на unknown)
    │                                # + entity_schema/object/navigation_item (11b)
    ├── services/…                   # RpcClient (MockClient), AuthService (mocktail),
    │                                # WsClient (локальный WS-сервер), widget smoke,
    │                                # MetadataService/ObjectService (mocktail, 11b)
    ├── screens/…                    # CatalogScreen/ObjectFormScreen (11b, test/support)
    ├── sdui/…                       # WidgetRegistry + тип-виджеты (11b)
    └── support/…                    # фикстуры/роутер-харнесс/FakeObjectService (11b)
```

---

## 4. Ключевые решения

- **Стейт:** Riverpod 2.x (ТЗ §3); **роутинг:** go_router (deep-link-ready).
- **HTTP:** `http` (один POST + таймаут; dio не нужен до Фазы 12).
- **WS:** `web_socket_channel`, reconnect с exponential backoff (старт 1 c, cap 30 c).
- **Токен:** `flutter_secure_storage` (libsecret на Linux: пакеты
  `libsecret-1-dev` + `jsoncpp`).
- **Токен НЕ хранить** в plaintext; пароль не хранить вовсе.
- **Идемпотентность:** уникальный UUID в `id` каждого Command.
- **Union-теги freezed:** задаются явно через `@FreezedUnionValue('snake_case')`
  (`event_batch`, `server_push`); дефолт freezed — camelCase, серверу не подходит.
- **Неизвестный тип в RpcMessage** → freezed бросает `CheckedFromJsonException`
  (json_annotation) — фатально, без деградации (жёсткий контракт).
- **`flutter build windows`** — только на Windows-хосте (нет кросс-компиляции).
- **11b (SDUI):** типы сущностей/полей — ТОЛЬКО из метаданных (`metadata.schema.get`),
  никаких захардкоженных форм; список полей — `orderedFields` по `order`.
- **11b:** сетевые команды по смыслу 1×1 с RPC; виджеты строятся статическим
  `WidgetRegistry.instance`; неизвестный `data_type` → read-only поле (fallback,
  не падение); тип `money` — только целые копейки, деньги в таблицах и формах
  форматируются `SduiMoneyField.format` («12,34»), дробная часть заменяет запятую.
- **11b:** OCC-обновление через `expected_version` (версия из загруженного объекта);
  `CONFLICT_ERROR` → AlertDialog «Конфликт версий» (ручное разрешение, ADR-009).
- **11b:** `company_id` в запросах опускается при null/пусто (JWT без компании);
  `object.create` от клиента требует `kind` из схемы (обязателен сервером).
- **11b:** навигация клиента = `module.navigation` (drawer секции модулей → каталоги),
  деплинки `/catalog/:entityType`, `/object/:entityType/:id`, `/object/:entityType/:id/edit`.

---

## 5. Критерии приёмки Фазы 11a

1. `flutter build linux` собирается; `flutter build windows` — на Windows-машине. ✅
   (linux OK; потребовались `libsecret-1-dev` + `libjsoncpp-dev`, сброс
   `build/linux` из-за ошибочного `CMAKE_INSTALL_PREFIX=/usr/local` в cache)
2. Модель `RpcMessage` — все 6 вариантов, round-trip совпадает с сервером. ✅
3. Логин через `user.login` → JWT в secure storage. ✅ (против живого сервера,
   payload = `access_token`/`expires_at`/`token_type`)
4. Команды через `POST /rpc` → `Response`/`Error`, русские сообщения об ошибках. ✅
5. WebSocket подключён → ServerPush принимается; индикатор соединения. ✅
   (live: `/ws?token=` + `/debug/push` → `server_push`)
6. Обрыв WS → автопереподключение. ✅ (backoff 1→30 с, в коде)
7. Тёмная тема (Material 3). ✅
8. Ошибки сервера → понятные сообщения (5 кодов + клиентский `AUTH_REQUIRED`). ✅
9. `flutter test` и `flutter analyze` без ошибок. ✅ (34 passed, 0 issues)
10. Автовосстановление сессии из secure storage при старте. ✅ (в коде, smoke-тест)

---

## 6. Журнал снимков

| Коммит | Дата | Что зафиксировано | Разделы отчёта |
|---|---|---|---|
| `e7e6c68` | 2026-09-17 | Фаза 15.3 done: Rhai-редактор — подсветка (`core/rhai_grammar.dart`, Mode из rust.dart, `flutter_highlight` фоном + прозрачный `TextField`, тема из colorScheme, `registerRhaiHighlight`) и пре-чек «;» (`core/rhai_precheck.dart`, консервативный: блоки/заголовки/скобки/комментарии/последний оператор), Switch «strict „;\"" блокирует сохранение с координатой, панель «Клиентский пре-чек:» (де: обновление на ввод через `onChanged`); +11 тестов (precheck 10, editor 3) → 172, analyze 0. + `doc/TZ_v3.1_1.md` (спека Расширения 1, дополнение к ТЗ v3.1). | §1, §2, §3 |
| `772bd07` | 2026-09-17 | Фаза 15.2 done: каталог скриптов — `ScriptItem`, `ScriptService` (list/get/create/update/delete/validate/testRun), `scriptsProvider`, `ScriptListScreen` `/scripts` (DataTable + метки типов, FAB, RefreshIndicator), `ScriptEditorScreen` `/scripts/new`+`/scripts/:code/edit` (форма, «Проверить»=validate с панелью координат, «Прогнать»=test с временем), пункт «Скрипты» в home за `script.manage`; сервер: пункт `scripts` в `get_navigation`, phase11_navigation 8/8 (admin видит, staff — нет); +27 тестов (model 4/service 11/list 5/editor 8) + home-кейс → 159, analyze 0. | §1, §2, §3 |
| `5caf46f` | 2026-09-16 | Фаза 15pre-3 done: редактор метаданных + экспорт/импорт — `toJson/copyWith` моделей, `MetadataService.createEntityType`/`exportMetadata`/`importMetadata`, SDUI-редактор `metadata_editor_screen` (секции Поля/Состояния/Переходы, каскадное удаление переходов, guard последнего состояния, бамп `metadata_version`, экспорт/импорт JSON), пункт «Метаданные» + роут `/metadata/editor/:entityType?`; +10 тестов → 131, analyze 0, build linux OK. | §1, §2, §9 |
| `2a837d6` | 2026-09-16 | Фаза 15pre-2 done: SDUI ядровых сущностей — synthetic-модуль `platform` в `module.navigation` («Компании»/«Пользователи»/«Роли»), каталоги/формы через Catalog/ObjectForm без изменения wire-контракта, фильтр по компании актора; +9 тестов → 121, analyze 0. | §1, §2, §9 |
| `63b290c` | 2026-09-11 | Сервер: access TTL JWT 1ч → 8ч (`main.rs`); сделан под 11a (не клиентский коммит, но зависимость) | §1 |
| `c367e26` | 2026-09-12 | Фаза 11a done: каркас Flutter-клиента (RpcMessage 6, RpcClient, WsClient+reconnect, AuthService, провайдеры+routerRefresh, экраны login/home/settings, тёмная тема, 34 теста, analyze чист, build linux OK). Интеграция против живого сервера: login→JWT 8ч, PERMISSION_ERROR, WS+push. | §1, §2, §3, §4, §5 |
| `302e224` | 2026-09-15 | Фаза 11b done: SDUI-рендеринг (модели entity_schema/object/navigation_item, MetadataService/ObjectService, sdui_providers, WidgetRegistry + 12 тип-виджетов, CatalogScreen, ObjectFormScreen + OCC/конфликт, роуты, drawer из module.navigation, home_screen; payload→Object?, queryAny). 58 новых тестов (92 всего), analyze 0, build linux OK. | §1, §2, §3, §4, §5 |
| `7545835` | 2026-09-15 | Live-прогон 11b: зафиксирован журнал верификации §8; находка — `metadata.schema.get` требует `company_id` (клиент не слал, сервер не подставляет компанию актора); фикс `MetadataService.fetchSchema` + `schemaProvider` (компания из claims), +1 тест (93 passed, analyze 0). | §6, §7, §8 |

## 7. Критерии приёмки Фазы 11b

1. Каталог любого типа сущности рендерится из `metadata.schema.get` (без hardcode). ✅
2. Форма просмотра/создания/редактирования собирается из полей схемы. ✅
3. Редактирование — OCC (`expected_version`); конфликт → AlertDialog. ✅
4. Модули из `module.navigation` показаны в drawer и на главном экране. ✅
5. Деплинки `/catalog/:entityType`, `/object/:entityType/{new|:id|:id/edit}` работают. ✅
6. Модели/сервисы/виджеты/экраны покрыты тестами: 92 passed (58 новых). ✅
7. `flutter analyze` — 0 issues; `flutter build linux` — OK. ✅
8. Деньги только целыми копейками; типы без виджета → read-only. ✅
9. **Live-прогон против живого сервера** (login → каталог → создание/редактирование
   реального объекта) — ✅ 2026-09-15 (см. Журнал верификации §8).

## 8. Журнал верификации (live-прогон 2026-09-15)

**Окружение:** SurrealDB на 192.168.0.202:8000 (ns `main`, db `2cplatform_v30`),
локальный `platform-server` на :8080 (61 команда); компания **11b_demo**
(`ca32248e-bbdc-4820-94f1-0a06280329c6`), админ **admin11b** (JWT с `company_id`
в claims), модуль **accounting** переустановлен на актуальную фикстуру (навигация).

Прогнанные RPC-контракты ровно как шлёт клиент (`/rpc` + `Authorization: Bearer`,
запросы `module/core`):

| Шаг | Запрос | Результат |
|---|---|---|
| 1 | `user.login {login, password}` | access_token (JWT), claims: sub/login/full_name/position/company_id |
| 2 | `module.navigation {}` | `{modules:[{code:accounting, display_name:«Управленческий учёт», navigation:[accounts→account, periods→accounting_period, entries→ledger_entry]}]}` — контракт клиента (label/entity_type) совпал |
| 3 | `metadata.schema.get {code}` (без company_id) | **NOT_FOUND_ERROR** «Объект не найден: Тип сущности» |
| 4 | `metadata.schema.get {code, company_id}` | Схема account: 4 поля (code/name string req, account_type enum [asset,liability,equity,revenue,expense,off_balance] req, is_active boolean req) |
| 5 | `object.list {entity_type:account, company_id}` | `[]` → после create отдаёт объект |
| 6 | `object.create {entity_type, kind:catalog, data}` | object, version 1, state draft (initial) |
| 7 | `object.get {id}` | объект полностью, data как создан |
| 8 | `object.update {id, expected_version, data}` — частичный data | **VALIDATION_ERROR** «Поле 'account_type' … обязательное» — сервер валидирует полный data |
| 9 | `object.update` с полным data, v1→v2 | version 2, «Касса основная» |
| 10 | `object.update` со stale version 1 | **CONFLICT_ERROR** «Конфликт версий: ожидалась 1, актуальная 2» → клиентский AlertDialog «Конфликт версий» |
| 11 | `object.list` после обновления | один объект, version 2 |
| 12 | без `Authorization` | **PERMISSION_ERROR** «Недостаточно прав на команду object.list» |

**Найденные в прогоне факты/неожиданности:**
1. `metadata.schema.get` ищет схему по (company_id, code) без подстановки компании
   актора: без `company_id` → NOT_FOUND. **Клиент исправлен** — `MetadataService.fetchSchema`
   и `schemaProvider` теперь передают `company_id` из claims (тест добавлен, 93 теста passed).
2. `metadata.entity_type.list` отдаёт типы **всех** компаний с дубликатами
   (account ×2 для разных компаний) — не скоуплен по актору. Клиенту не мешает
   (каталог строится по кодам из `module.navigation`), но при росте числа компаний
   стоит скоупить сервером.
3. `object.update` принимает **полный** data (валидация required-полей на каждом
   обновлении) — клиент шлёт все editable-поля из префилла формы, поведение согласовано. 
4. OCC-конфликт приходит wire-кодом `CONFLICT_ERROR` → маппится в диалог «Конфликт версий».

## 9. Журнал верификации — автоматический integration-прогон (2026-09-15)

`integration_test/sdui_live_test.dart` (`flutter test integration_test/sdui_live_test.dart -d linux`)
против живого сервера (тот же стенд: admin11b, компания ca32248e, объект «Касса основная»,
модуль accounting из `module.navigation`). Прогон итерировался против реальной схемы
и реальных ответов; финальный — **All tests passed**, шаги:

| Шаг | Сценарий | Результат |
|---|---|---|
| 1 | Вход admin11b/… через UI (login-экран) | home, разделы из `module.navigation` («План счетов», «Учётные периоды») |
| 2 | Каталог account (tap «План счетов») | DataTable со строкой демо-объекта (код 001) |
| 3 | view → edit → смена имени → Сохранить | объект обновлён (проверка по `objectService.list`) |
| 4 | FAB → форма создания → код live-int, имя, enum asset → Сохранить | объект уехал на сервер (list содержит code=live-int) |
| 5 | OCC-конфликт: форма edit держит v_old, серверно 2×update (v+1, v+2) → Сохранить | **CONFLICT_ERROR «ожидалась old, актуальная v+2»** → диалог «Конфликт версий» → OK, форма остаётся для ручного разрешения |
| 6 | Settings → переключатель темы → «Светлая» | `Theme.brightness == light` и `config.toml` содержит `theme = "light"` |

**Найденные в прогоне факты:**
1. Пока шёл вход, `HomeScreen` монтировался до завершения `AuthRestoring` и сетевые
   провайдеры (`module.navigation` и др.) кэшировали **анонимный PERMISSION_ERROR**,
   который не перезапрашивался после логина. **Клиент исправлен**: роутер в
   `AuthRestoring` редиректит на `/login`, а `sdui_providers` подписаны на новый
   `_authRevision` (инкрементируется при смене AuthState) — провайдеры перезапускаются
   после входа/выхода. Фиксы вошли в коммит `test(phase11b)`.
2. Реальная схема account: entity_type.name «Счёт плана счетов», поля
   code/name/is_active + enum account_type (плоский список), все order=0
   (порядок вставки); демо-объект стабильно ищется по коду «001» (имя меняется
   прогонами), поэтому тест завязан на код, а не имя.
3. После сохранения из edit `pop` возвращал на экран просмотра, а не в каталог —
   тест возвращается через `router.go('/catalog/account')`.

**Регрессия после фиксов 11b.6/live:** `flutter analyze` — 0 issues; юнит-тесты — 112 passed;
`flutter build linux` — OK.

## 9. Журнал верификации — Расширение 1 (15pre-2/15pre-3), live-прогон 2026-09-16

Тот же стенд, что в §8: SurrealDB 192.168.0.202:8000 (ns `main`, db
`2cplatform_v30`), локальный `platform-server` :8080; клиент — `2c_client`
(linux). Прогон выполнен после засева системных метаданных
(`system.bootstrap`, Фаза 15pre-1) и пересборки клиента.

| Шаг | Сценарий | Результат |
|---|---|---|
| 1 | Вход админа через UI (login-экран) | home, разделы из `module.navigation`, включая synthetic-модуль `platform` («Компании», «Пользователи», «Роли») |
| 2 | Каталог «Компании» (`/catalog/company`) | DataTable из системной схемы `company` (is_system, глобальная схема `company_id=""`); список скоуплен по компании актора |
| 3 | FAB → форма создания компании (поля code/name из схемы) → Сохранить | `object.create {entity_type:"company", kind, data}` → создана компания, в Трубе событие `company.created`; объект виден в `object.get` по id |
| 4 | Каталог «Пользователи»/«Роли» | рендерятся из системных схем `user`/`role`; доступ к действиям ограничен правами актора (deny-by-default) |
| 5 | Пункт «Метаданные» (`/metadata/editor`) → выбор типа + сохранение | `metadata.schema.get` → секции Поля/Состояния/Переходы; сохранение бампит `metadata_version` и уходит `metadata.import`; экспорт возвращает JSON-схему |
| 6 | `flutter analyze` + юнит-тесты после прогона | 0 issues; 131 passed (121 старых + 9 + новые правки 15pre-3) |

**Факты live-прогона:**
1. Ядровые сущности отдают тот же `object.*`-wire-контракт, что и обычные
   каталоги — делегация `object.create/list/get/update` → `company.*`/`user.*`/
   `role.*` прозрачна для клиента, отдельных путей в клиенте не требуется.
2. Списки ядровых сущностей фильтруются по компании актора (через роли) —
   «чужие» компании/пользователи/роли не видны.
3. Редактор метаданных работает по существующим `metadata.schema.get`/
   `metadata.export`/`metadata.import` — без новых эндпоинтов.

После live-прогона Расширения 1 клиентская регрессия чистая (п. 6).
Фаза 15 (Rhai-редактор скриптов): серверные подфазы 15.1 (`38180e4`) и 15.4
(`2bcf6d0`) завершены, клиентские подфазы 15.2 (каталог скриптов, `772bd07`)
и 15.3 (редактор с подсветкой + пре-чек, `e7e6c68`) завершены; 15.4 —
серверная (авто-хук привязанных скриптов: formula/validator/before/after в
object.create/update), клиент не менялся (привязанные скрипты редактируются
существующим ScriptEditorScreen через `entity_type`).